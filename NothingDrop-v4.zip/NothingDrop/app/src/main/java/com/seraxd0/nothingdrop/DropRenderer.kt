package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Soft-body jiggle renderer shared by the live wallpaper, the in-app live preview and the Test screen.
 *
 * Physics: every grid node inside the painted area is a damped spring (anchored more strongly near the
 * mask edge) coupled to its 4 neighbours, so taps make ripples and shakes make the far parts lag/overshoot.
 * Speed: only the bounding box of the painted area is simulated and redrawn (dirty rect), frames are only
 * produced while something moves, FPS is capped by a setting, nothing is allocated per frame.
 * Stability: the scene is built on a background thread; draw() never throws. Call from the main thread.
 */
class DropRenderer(ctx: Context, private val redraw: () -> Unit) : SensorEventListener {
    private class Scene(
        val full: Bitmap, val region: Bitmap, val rect: Rect,
        val px0: Int, val py0: Int, val rc: Int, val rr: Int,
        val base: FloatArray, val verts: FloatArray,
        val w: FloatArray, val ka: FloatArray, val sq: FloatArray, val rad: FloatArray,
        val act: IntArray, val nb: IntArray,
        val dx: FloatArray, val dy: FloatArray, val vx: FloatArray, val vy: FloatArray,
        val ax: FloatArray, val ay: FloatArray, val cx: Float, val cy: Float
    )

    private val app = ctx.applicationContext
    private val sm = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val main = Handler(Looper.getMainLooper())
    private var W = 0
    private var H = 0
    private var visible = false
    private var running = false
    private var dead = false
    private var loading = false
    private var gen = 0
    private var key = ""
    private var scene: Scene? = null
    private var err: String? = null
    private var needFull = true

    // settings (see applySettings)
    private var maxPx = 0f
    private var zeta = 0.3f
    private var om0 = 10f
    private var kn = 600f
    private var kd = 20f
    private var spread = 0.6f
    private var tiltGain = 1f
    private var shakeGain = 1f
    private var touchGain = 1f
    private var idleAmp = 0f
    private var frameNs = 16_666_667L
    private var passes = 3
    private var touchOn = true
    private var invert = false

    // dynamic state
    private var tgtX = 0f
    private var tgtY = 0f
    private var curTX = 0f
    private var curTY = 0f
    private var settledTX = 0f
    private var settledTY = 0f
    private var simT = 0f
    private var maxD = 0f
    private var maxV = 0f
    private var maxE = 0f
    private val g = FloatArray(3)
    private val gs = FloatArray(3)
    private var haveG = false
    private var lastNs = 0L
    private var lastSensor = 0L
    private var lastPoke = 0L
    private var firstFrame = true
    private var perfN = 0
    private var perfSum = 0L

    private val frame = Choreographer.FrameCallback { t ->
        running = false
        if (visible && !dead) {
            try {
                val interval = if (idleAmp > 0f) max(frameNs, 33_000_000L) else frameNs
                if (lastNs != 0L && t - lastNs < interval - 2_000_000L) {
                    go() // too early for the FPS cap: wait for the next vsync
                } else {
                    val dt = if (lastNs == 0L) 0.016f else ((t - lastNs) / 1e9f).coerceIn(0.001f, 0.05f)
                    lastNs = t
                    simT += dt
                    step(dt)
                    redraw()
                    if (settled()) {
                        lastNs = 0; settledTX = curTX; settledTY = curTY
                    } else go()
                }
            } catch (e: Throwable) {
                Dbg.log("frame failed", e)
            }
        }
    }

    private fun go() {
        if (!running && visible && !dead) {
            running = true
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun settled() = scene == null || (idleAmp == 0f && maxV < 1f && maxE < 0.25f)

    // ------------------------------------------------------------ lifecycle

    fun setSize(w: Int, h: Int) {
        if (dead || w <= 0 || h <= 0 || (w == W && h == H)) return
        W = w; H = h
        Dbg.log("surface size ${w}x$h")
        reload(true)
    }

    /** Re-read settings; rebuilds the scene only if the photo/mask/edge-softness changed. */
    fun refresh() = reload(false)

    fun markFull() { needFull = true }

    /** Region to redraw for a moving frame, or null when the whole surface must be drawn. */
    fun dirtyRect(): Rect? {
        val s = scene ?: return null
        return if (needFull) null else s.rect
    }

    fun setVisible(v: Boolean) {
        if (dead || v == visible) return
        visible = v
        Dbg.log("visible=$v")
        if (v) {
            reload(false)
            needFull = true
            haveG = false; lastNs = 0; lastSensor = 0
            try {
                if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
                else Dbg.log("no accelerometer: tilt/shake disabled")
            } catch (e: Throwable) {
                Dbg.log("sensor register failed", e)
            }
            redraw()
            if (idleAmp > 0f) go()
        } else {
            try { sm.unregisterListener(this) } catch (e: Throwable) { }
            Choreographer.getInstance().removeFrameCallback(frame)
            running = false
        }
    }

    fun release() {
        dead = true
        try { sm.unregisterListener(this) } catch (e: Throwable) { }
        Choreographer.getInstance().removeFrameCallback(frame)
        scene = null
        Dbg.log("renderer released")
    }

    private fun applySettings(): String {
        val sp = Store.prefs(app)
        fun i(k: String, d: Int) = sp.getInt(k, d)
        maxPx = (0.01f + 0.05f * i("strength", 50) / 100f) * W
        zeta = 0.9f - 0.82f * i("elasticity", 60) / 100f
        om0 = 5f + 11f * i("stiffness", 50) / 100f
        val j = i("jelly", 50) / 100f
        kn = 1200f * (1f - 0.85f * j)
        kd = 0.8f * sqrt(2f * kn)
        spread = 1.2f * j
        tiltGain = i("tilt", 50) / 50f
        shakeGain = i("shake", 50) / 50f
        touchGain = i("touchForce", 50) / 50f
        idleAmp = i("idle", 0) / 100f * maxPx * 0.35f
        frameNs = (1e9f / i("fps", 60).coerceIn(15, 240)).toLong()
        passes = 1 + i("feather", 50) * 5 / 100
        touchOn = sp.getBoolean("touch", true)
        invert = sp.getBoolean("invert", false)
        return "${sp.getLong("rev", 0)}|$passes"
    }

    private fun reload(force: Boolean) {
        if (dead || W == 0 || H == 0) return
        val k = applySettings()
        if (!force && k == key && (scene != null || loading)) return
        key = k
        val id = ++gen
        val w = W
        val h = H
        val ps = passes
        loading = true
        Dbg.log("reload start ${w}x$h key=$k")
        Thread({
            try {
                val s = build(w, h, ps)
                main.post {
                    if (!dead && id == gen) {
                        scene = s; err = null; loading = false; needFull = true
                        maxD = 0f; maxV = 0f; maxE = 0f; settledTX = 0f; settledTY = 0f
                        redraw()
                        if (idleAmp > 0f) go()
                    }
                }
            } catch (t: Throwable) {
                Dbg.log("scene build failed", t)
                main.post {
                    if (!dead && id == gen) {
                        scene = null; loading = false
                        err = "${t.javaClass.simpleName}: ${t.message}"
                        redraw()
                    }
                }
            }
        }, "nd-build").start()
    }

    // ------------------------------------------------------------ scene

    private fun build(sw: Int, sh: Int, passes: Int): Scene {
        val t0 = System.nanoTime()
        val (photo, m) = Store.load(app) ?: throw IllegalStateException(Store.error ?: "No saved photo")
        val pw = photo.width
        val ph = photo.height
        if (m.none { it.toInt() != 0 }) throw IllegalStateException("Saved mask is empty")
        val cell = max(16, sw / 45)
        val cols = (sw + cell - 1) / cell
        val rows = (sh + cell - 1) / cell
        val bw = cols * cell
        val bh = rows * cell
        val sc = max(bw.toFloat() / pw, bh.toFloat() / ph)
        val dw = pw * sc
        val dh = ph * sc
        val full = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        Canvas(full).apply {
            drawColor(Color.BLACK)
            drawBitmap(photo, null, RectF((bw - dw) / 2, (bh - dh) / 2, (bw + dw) / 2, (bh + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        photo.recycle()

        // mask weight per grid node (5 samples), then soften the edge
        val ox = (dw - bw) / 2
        val oy = (dh - bh) / 2
        val nc = cols + 1
        val wt = FloatArray(nc * (rows + 1))
        fun at(x: Float, y: Float): Float {
            val i = ((x + ox) / sc).toInt().coerceIn(0, pw - 1)
            val j = ((y + oy) / sc).toInt().coerceIn(0, ph - 1)
            return (m[j * pw + i].toInt() and 255) / 255f
        }
        val hf = cell / 2f
        for (j in 0..rows) for (i in 0..cols) {
            val x = (i * cell).toFloat()
            val y = (j * cell).toFloat()
            wt[j * nc + i] = (2 * at(x, y) + at(x - hf, y - hf) + at(x + hf, y - hf) +
                at(x - hf, y + hf) + at(x + hf, y + hf)) / 6
        }
        repeat(passes) { blur(wt, nc, rows + 1) }

        // fade near the screen border; bounding box of the active nodes
        var i0 = cols; var i1 = -1; var j0 = rows; var j1 = -1
        for (j in 0..rows) for (i in 0..cols) {
            val k = j * nc + i
            wt[k] *= min(1f, min(min(i, cols - i), min(j, rows - j)) / 3f)
            if (wt[k] > 0.003f) {
                if (i < i0) i0 = i
                if (i > i1) i1 = i
                if (j < j0) j0 = j
                if (j > j1) j1 = j
            }
        }
        if (i1 < 0) throw IllegalStateException("Painted area too small")

        // region = bounding box + margin big enough for the largest possible displacement
        val margin = ceil(0.06f * 2.2f * sw / cell).toInt() + 2
        val c0 = max(0, i0 - margin)
        val c1 = min(cols, i1 + margin)
        val r0 = max(0, j0 - margin)
        val r1 = min(rows, j1 + margin)
        val rc = c1 - c0
        val rr = r1 - r0
        if (rc < 1 || rr < 1) throw IllegalStateException("Region too small")
        val rn = rc + 1
        val n = rn * (rr + 1)
        val base = FloatArray(n * 2)
        val w = FloatArray(n + 1)
        val ka = FloatArray(n + 1)
        val sq = FloatArray(n + 1)
        val rad = FloatArray(n + 1)
        val list = ArrayList<Int>()
        var aw = 0f
        var ax = 0f
        var ay = 0f
        for (j in 0..rr) for (i in 0..rc) {
            val k = j * rn + i
            base[2 * k] = ((c0 + i) * cell).toFloat()
            base[2 * k + 1] = ((r0 + j) * cell).toFloat()
            val wk = wt[(r0 + j) * nc + (c0 + i)]
            if (wk > 0.003f) {
                w[k] = wk
                ka[k] = 0.35f + 5f * (1f - wk) * (1f - wk)
                sq[k] = sqrt(ka[k])
                list.add(k)
                aw += wk; ax += wk * base[2 * k]; ay += wk * base[2 * k + 1]
            }
        }
        val cx = if (aw > 0) ax / aw else sw / 2f
        val cy = if (aw > 0) ay / aw else sh / 2f
        var md = 1f
        for (k in list) md = max(md, hypot(base[2 * k] - cx, base[2 * k + 1] - cy))
        for (k in list) rad[k] = hypot(base[2 * k] - cx, base[2 * k + 1] - cy) / md
        val act = list.toIntArray()
        val nb = IntArray(act.size * 4)
        for (a in act.indices) {
            val k = act[a]
            val i = k % rn
            val j = k / rn
            nb[4 * a] = if (i > 0) k - 1 else n
            nb[4 * a + 1] = if (i < rc) k + 1 else n
            nb[4 * a + 2] = if (j > 0) k - rn else n
            nb[4 * a + 3] = if (j < rr) k + rn else n
        }
        val region = Bitmap.createBitmap(full, c0 * cell, r0 * cell, rc * cell, rr * cell)
        val rect = Rect(c0 * cell, r0 * cell, c1 * cell, r1 * cell)
        if (!rect.intersect(0, 0, sw, sh)) rect.set(0, 0, sw, sh)
        Dbg.log(
            "scene built ${sw}x$sh photo=${pw}x$ph cell=$cell region=${rc}x$rr of ${cols}x$rows " +
                "active=${act.size} passes=$passes in ${(System.nanoTime() - t0) / 1_000_000}ms"
        )
        return Scene(
            full, region, rect, c0 * cell, r0 * cell, rc, rr, base, base.copyOf(),
            w, ka, sq, rad, act, nb,
            FloatArray(n + 1), FloatArray(n + 1), FloatArray(n + 1), FloatArray(n + 1),
            FloatArray(n + 1), FloatArray(n + 1), cx, cy
        )
    }

    private fun blur(a: FloatArray, w: Int, h: Int) {
        val o = FloatArray(a.size)
        for (j in 0 until h) for (i in 0 until w) {
            var s = 0f
            for (dj in -1..1) for (di in -1..1)
                s += a[(j + dj).coerceIn(0, h - 1) * w + (i + di).coerceIn(0, w - 1)]
            o[j * w + i] = s / 9
        }
        o.copyInto(a)
    }

    // ------------------------------------------------------------ drawing

    /** full=false: only the dirty region is on the canvas (clip already set by lockCanvas). */
    fun draw(c: Canvas, full: Boolean = true) {
        val t0 = System.nanoTime()
        try {
            val s = scene
            if (s == null) {
                c.drawColor(0xFF111318.toInt())
                note(c, err ?: if (loading) "Loading…" else "Nothing saved yet. Open NothingDrop, paint an area and tap Set wallpaper.")
                needFull = true
                return
            }
            if (full) { c.drawBitmap(s.full, 0f, 0f, null); needFull = false }
            if (maxD >= 0.02f) c.drawBitmapMesh(s.region, s.rc, s.rr, s.verts, 0, null, 0, null)
            else if (!full) c.drawBitmap(s.region, s.px0.toFloat(), s.py0.toFloat(), null)
            if (firstFrame) { firstFrame = false; Dbg.log("first frame drawn ${c.width}x${c.height}") }
            perfSum += System.nanoTime() - t0
            if (++perfN >= 180) {
                Dbg.log("perf: avg draw ${perfSum / perfN / 1000}us over $perfN frames, region ${s.rect.width()}x${s.rect.height()}")
                perfN = 0; perfSum = 0
            }
        } catch (t: Throwable) {
            Dbg.log("draw failed", t)
            try { c.drawColor(0xFF111318.toInt()); note(c, "draw: $t"); needFull = true } catch (e: Throwable) { }
        }
    }

    private fun note(c: Canvas, msg: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = c.width / 26f }
        var yy = c.height / 2f
        for (line in msg.chunked(30)) {
            c.drawText(line, 40f, yy, p)
            yy += p.textSize * 1.3f
        }
    }

    // ------------------------------------------------------------ physics

    private fun step(dt: Float) {
        val s = scene ?: return
        val sub = min(4, max(1, ceil(dt / 0.0085f).toInt()))
        val h = dt / sub
        val om2 = om0 * om0
        val cd = 2f * zeta * om0
        val tX = tgtX + if (idleAmp > 0f) idleAmp * sin(simT * 1.2f) else 0f
        val tY = tgtY + if (idleAmp > 0f) idleAmp * sin(simT * 0.83f + 1.3f) else 0f
        curTX = tX; curTY = tY
        val lim = maxPx * 2.2f
        val act = s.act; val nb = s.nb; val w = s.w; val ka = s.ka; val sq = s.sq
        val dx = s.dx; val dy = s.dy; val vx = s.vx; val vy = s.vy; val ax = s.ax; val ay = s.ay
        var mv = 0f; var me = 0f; var mdis = 0f
        repeat(sub) {
            for (a in act.indices) {
                val k = act[a]
                val b = a * 4
                val n0 = nb[b]; val n1 = nb[b + 1]; val n2 = nb[b + 2]; val n3 = nb[b + 3]
                val kk = om2 * ka[k]
                val c = cd * sq[k]
                val avx = (dx[n0] + dx[n1] + dx[n2] + dx[n3]) * 0.25f
                val avy = (dy[n0] + dy[n1] + dy[n2] + dy[n3]) * 0.25f
                val avvx = (vx[n0] + vx[n1] + vx[n2] + vx[n3]) * 0.25f
                val avvy = (vy[n0] + vy[n1] + vy[n2] + vy[n3]) * 0.25f
                ax[k] = kk * (w[k] * tX - dx[k]) - c * vx[k] + kn * (avx - dx[k]) + kd * (avvx - vx[k])
                ay[k] = kk * (w[k] * tY - dy[k]) - c * vy[k] + kn * (avy - dy[k]) + kd * (avvy - vy[k])
            }
            mv = 0f; me = 0f; mdis = 0f
            for (a in act.indices) {
                val k = act[a]
                vx[k] += ax[k] * h
                vy[k] += ay[k] * h
                dx[k] = (dx[k] + vx[k] * h).coerceIn(-lim, lim)
                dy[k] = (dy[k] + vy[k] * h).coerceIn(-lim, lim)
                val v = abs(vx[k]) + abs(vy[k])
                if (v > mv) mv = v
                val e = abs(w[k] * tX - dx[k]) + abs(w[k] * tY - dy[k])
                if (e > me) me = e
                val d = abs(dx[k]) + abs(dy[k])
                if (d > mdis) mdis = d
            }
        }
        maxV = mv; maxE = me; maxD = mdis
        val vt = s.verts; val bs = s.base
        for (k in act) { vt[2 * k] = bs[2 * k] + dx[k]; vt[2 * k + 1] = bs[2 * k + 1] + dy[k] }
    }

    /** Impulse on every node, stronger for nodes far from the centre (they swing/lag more). */
    private fun kickAll(ix: Float, iy: Float) {
        val s = scene ?: return
        val vm = maxPx * 20
        for (k in s.act) {
            val f = s.w[k] * (1f + spread * s.rad[k])
            s.vx[k] = (s.vx[k] + ix * f).coerceIn(-vm, vm)
            s.vy[k] = (s.vy[k] + iy * f).coerceIn(-vm, vm)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        try {
            val a = e.values
            if (!haveG) { for (i in 0..2) { g[i] = a[i]; gs[i] = a[i] }; haveG = true }
            for (i in 0..2) { g[i] += 0.12f * (a[i] - g[i]); gs[i] += 0.01f * (a[i] - gs[i]) }
            // tilt: the object slides "downhill" relative to how the phone was being held
            val kt = maxPx / 4.9f * tiltGain * (if (invert) -1f else 1f)
            val lim = maxPx * 1.3f
            tgtX = (-(g[0] - gs[0]) * kt).coerceIn(-lim, lim)
            tgtY = ((g[1] - gs[1]) * kt).coerceIn(-lim, lim)
            // shake: inertia kick opposite to the phone's own acceleration
            val dt = if (lastSensor == 0L) 0.02f else ((e.timestamp - lastSensor) / 1e9f).coerceIn(0.005f, 0.05f)
            lastSensor = e.timestamp
            val lx = a[0] - g[0]
            val ly = a[1] - g[1]
            val kick = abs(lx) + abs(ly) > 1.5f
            if (kick) {
                val gain = maxPx * 6 * dt * shakeGain
                kickAll(-lx * gain, ly * gain)
            }
            if (scene != null && (kick || abs(tgtX - settledTX) > 0.5f || abs(tgtY - settledTY) > 0.5f)) go()
        } catch (t: Throwable) {
            Dbg.log("sensor failed", t)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    /** Tap: whole object is pushed away from the finger and a ripple spreads from the touch point. */
    fun poke(px: Float, py: Float) {
        val s = scene ?: return
        val now = System.nanoTime()
        if (!touchOn || !visible || now - lastPoke < 120_000_000L) return
        lastPoke = now
        val v0 = maxPx * om0 * 1.2f * touchGain
        val sig = 0.3f * max(W, H)
        val vm = maxPx * 20
        val gx = s.cx - px
        val gy = s.cy - py
        val gd = hypot(gx, gy).coerceAtLeast(1f)
        for (k in s.act) {
            val ddx = s.base[2 * k] + s.dx[k] - px
            val ddy = s.base[2 * k + 1] + s.dy[k] - py
            val d = hypot(ddx, ddy).coerceAtLeast(1f)
            val q = d / sig
            val f = exp(-q * q) * s.w[k] * v0
            val ux = 0.6f * gx / gd + 0.4f * ddx / d
            val uy = 0.6f * gy / gd + 0.4f * ddy / d
            s.vx[k] = (s.vx[k] + ux * f).coerceIn(-vm, vm)
            s.vy[k] = (s.vy[k] + uy * f).coerceIn(-vm, vm)
        }
        go()
    }
}
