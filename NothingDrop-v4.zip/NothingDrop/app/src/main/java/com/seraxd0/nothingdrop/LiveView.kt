package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.Canvas
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View

/** In-editor live preview of the effect (same renderer as the wallpaper). Tilt, shake or tap it. */
class LiveView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    private var rend: DropRenderer? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
        rend = DropRenderer(c) { invalidate() }
    }

    fun refresh() { rend?.refresh() }

    private fun sync() { rend?.setVisible(isShown && windowVisibility == VISIBLE) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { rend?.setSize(w, h) }
    override fun onDraw(c: Canvas) { rend?.draw(c) }
    override fun onVisibilityChanged(changedView: View, visibility: Int) { super.onVisibilityChanged(changedView, visibility); sync() }
    override fun onWindowVisibilityChanged(visibility: Int) { super.onWindowVisibilityChanged(visibility); sync() }
    override fun onAttachedToWindow() { super.onAttachedToWindow(); sync() }
    override fun onDetachedFromWindow() { rend?.release(); rend = null; super.onDetachedFromWindow() }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.actionMasked == MotionEvent.ACTION_DOWN) rend?.poke(e.x, e.y)
        return true
    }
}
