package com.seraxd0.nothingdrop

import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var mask: MaskView
    private lateinit var live: LiveView
    private lateinit var status: TextView
    private lateinit var touch: MaterialSwitch
    private lateinit var invert: MaterialSwitch
    private lateinit var panePaint: View
    private lateinit var panePhysics: View
    private val sl = LinkedHashMap<String, Slider>()
    private var fps = 60

    private val ids = linkedMapOf(
        "strength" to R.id.s_strength, "elasticity" to R.id.s_elasticity, "stiffness" to R.id.s_stiffness,
        "jelly" to R.id.s_jelly, "tilt" to R.id.s_tilt, "shake" to R.id.s_shake,
        "touchForce" to R.id.s_touchForce, "dragRadius" to R.id.s_dragRadius, "feather" to R.id.s_feather, "idle" to R.id.s_idle
    )
    private val defs = mapOf("elasticity" to 60, "idle" to 0) // every other slider defaults to 50
    private val presetKeys = listOf("strength", "elasticity", "stiffness", "jelly", "tilt", "shake")
    private val presets = mapOf(
        R.id.pSubtle to intArrayOf(25, 35, 70, 20, 50, 40),
        R.id.pNatural to intArrayOf(50, 60, 50, 50, 50, 50),
        R.id.pJelly to intArrayOf(65, 75, 35, 85, 50, 60),
        R.id.pBouncy to intArrayOf(80, 90, 45, 60, 60, 70)
    )

    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) load(uri)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        mask = findViewById(R.id.mask)
        live = findViewById(R.id.live)
        status = findViewById(R.id.status)
        touch = findViewById(R.id.touch)
        invert = findViewById(R.id.invert)
        panePaint = findViewById(R.id.panePaint)
        panePhysics = findViewById(R.id.panePhysics)

        // saved settings -> controls (listeners are added afterwards so this doesn't write anything back)
        val sp = Store.prefs(this)
        for ((k, id) in ids) {
            val s = findViewById<Slider>(id)
            s.value = sp.getInt(k, defs[k] ?: 50).toFloat()
            sl[k] = s
        }
        touch.isChecked = sp.getBoolean("touch", true)
        invert.isChecked = sp.getBoolean("invert", false)
        fps = sp.getInt("fps", 60)
        for (s in sl.values) s.addOnChangeListener { _, _, fromUser -> if (fromUser) persist() }
        touch.setOnCheckedChangeListener { _, _ -> persist() }
        invert.setOnCheckedChangeListener { _, _ -> persist() }

        findViewById<MaterialButtonToggleGroup>(R.id.fpsGroup).apply {
            check(when (fps) { 30 -> R.id.f30; 90 -> R.id.f90; 120 -> R.id.f120; else -> R.id.f60 })
            addOnButtonCheckedListener { _, id, on ->
                if (on) {
                    fps = when (id) { R.id.f30 -> 30; R.id.f90 -> 90; R.id.f120 -> 120; else -> 60 }
                    persist()
                }
            }
        }
        findViewById<MaterialButtonToggleGroup>(R.id.presets).addOnButtonCheckedListener { _, id, on ->
            val v = presets[id]
            if (on && v != null) {
                presetKeys.forEachIndexed { i, k -> sl[k]?.value = v[i].toFloat() }
                persist()
            }
        }
        findViewById<MaterialButtonToggleGroup>(R.id.tabs).apply {
            addOnButtonCheckedListener { _, id, on -> if (on) showTab(id == R.id.tabPhysics) }
            check(R.id.tabPaint)
        }

        findViewById<Slider>(R.id.brushSize).addOnChangeListener { _, v, _ -> mask.brush = v / 100f }
        findViewById<MaterialButtonToggleGroup>(R.id.tools).apply {
            addOnButtonCheckedListener { _, id, on ->
                if (on) mask.tool = when (id) {
                    R.id.tEraser -> MaskView.Tool.ERASER
                    R.id.tAdd -> MaskView.Tool.WAND_ADD
                    R.id.tSub -> MaskView.Tool.WAND_SUB
                    else -> MaskView.Tool.BRUSH
                }
            }
            check(R.id.tBrush)
        }
        findViewById<View>(R.id.pick).setOnClickListener {
            pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<View>(R.id.apply).setOnClickListener { apply() }
        findViewById<View>(R.id.test).setOnClickListener {
            if (prepare()) startActivity(Intent(this, PreviewActivity::class.java))
        }
        findViewById<View>(R.id.logBtn).setOnClickListener { showLog() }

        Store.load(this)?.let { (bmp, m) -> mask.setImage(bmp, m); Dbg.log("restored saved photo ${bmp.width}x${bmp.height}") }
    }

    override fun onResume() {
        super.onResume()
        status.text = statusText()
        Dbg.log("status: ${status.text}")
    }

    /** Every setting is saved the moment it changes; the wallpaper and the live preview pick it up. */
    private fun persist(refresh: Boolean = true) {
        val e = Store.prefs(this).edit()
        for ((k, s) in sl) e.putInt(k, s.value.toInt())
        e.putBoolean("touch", touch.isChecked).putBoolean("invert", invert.isChecked).putInt("fps", fps).apply()
        if (refresh && live.isShown) live.refresh()
    }

    private fun showTab(physics: Boolean) {
        panePaint.visibility = if (physics) View.GONE else View.VISIBLE
        panePhysics.visibility = if (physics) View.VISIBLE else View.GONE
        if (physics) {
            mask.visibility = View.INVISIBLE
            live.visibility = View.VISIBLE
            if (!prepare()) { // nothing to preview yet -> go back to painting
                findViewById<MaterialButtonToggleGroup>(R.id.tabs).check(R.id.tabPaint)
            }
        } else {
            live.visibility = View.GONE
            mask.visibility = View.VISIBLE
        }
    }

    /** Is our wallpaper the active one on home / lock screen? */
    private fun statusText(): String = try {
        val wm = WallpaperManager.getInstance(this)
        val name = DropWallpaperService::class.java.name
        val home = wm.getWallpaperInfo(WallpaperManager.FLAG_SYSTEM)?.serviceName == name
        val lock = wm.getWallpaperInfo(WallpaperManager.FLAG_LOCK)?.serviceName == name
        "${Dbg.VERSION} · Home ${if (home) "✓" else "✗"} · Lock ${if (lock) "✓" else "✗"}"
    } catch (e: Exception) {
        Dbg.log("status check failed", e)
        "${Dbg.VERSION} · status unknown"
    }

    private fun load(uri: Uri) {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { d, info, _ ->
                d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val big = max(info.size.width, info.size.height)
                var n = 1
                while (big / n > 2000) n *= 2
                d.setTargetSampleSize(n)
            }
            Dbg.log("picked photo ${bmp.width}x${bmp.height} config=${bmp.config} alpha=${bmp.hasAlpha()}")
            mask.setImage(bmp, null)
        } catch (e: Exception) {
            Dbg.log("photo load failed", e)
            toast(R.string.load_failed)
        }
    }

    /** Pre-flight: photo present, something painted, files saved and read back correctly. */
    private fun prepare(): Boolean {
        val bmp = mask.image ?: return toast(R.string.pick_first)
        val m = mask.maskBytes()
        val painted = m.count { it.toInt() != 0 }
        if (painted == 0) return toast(R.string.paint_first)
        return try {
            persist(false)
            Store.save(this, bmp, m)
            val back = Store.load(this)
            val ok = back != null && back.first.width == bmp.width && back.first.height == bmp.height &&
                back.second.count { it.toInt() != 0 } == painted
            Dbg.log("saved ${bmp.width}x${bmp.height} painted=$painted verified=$ok")
            if (!ok) return toast("Saving failed – tap Log")
            if (live.isShown) live.refresh()
            true
        } catch (e: Exception) {
            Dbg.log("save failed", e)
            toast("Saving failed – tap Log")
        }
    }

    private fun apply() {
        if (!prepare()) return
        val cn = ComponentName(this, DropWallpaperService::class.java)
        try {
            packageManager.getServiceInfo(cn, 0)
        } catch (e: Exception) {
            Dbg.log("wallpaper service not found", e)
            toast("Wallpaper service missing – tap Log")
            return
        }
        val wm = WallpaperManager.getInstance(this)
        Dbg.log("launching preview: supported=${wm.isWallpaperSupported} allowed=${wm.isSetWallpaperAllowed}")
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, cn)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Dbg.log("CHANGE_LIVE_WALLPAPER failed, trying chooser", e)
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Dbg.log("chooser failed", e2)
                toast("Can't open wallpaper picker – tap Log")
            }
        }
    }

    private fun showLog() {
        val tv = TextView(this).apply {
            text = Dbg.read().ifEmpty { "(empty)" }
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(32, 16, 32, 16)
        }
        val sv = ScrollView(this).apply { addView(tv); post { fullScroll(View.FOCUS_DOWN) } }
        MaterialAlertDialogBuilder(this).setTitle("Log").setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("NothingDrop log", Dbg.read()))
                toast("Log copied")
            }
            .setNeutralButton("Clear") { _, _ -> Dbg.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun toast(s: String): Boolean {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        return false
    }

    private fun toast(id: Int): Boolean = toast(getString(id))
}
