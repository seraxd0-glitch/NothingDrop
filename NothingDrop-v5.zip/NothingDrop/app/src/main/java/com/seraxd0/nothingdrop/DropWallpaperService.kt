package com.seraxd0.nothingdrop

import android.app.WallpaperManager
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Bundle
import android.service.wallpaper.WallpaperService
import android.view.MotionEvent
import android.view.SurfaceHolder

/** Live wallpaper shell: all rendering lives in DropRenderer; every callback is crash-proof and logged. */
class DropWallpaperService : WallpaperService() {
    override fun onCreate() {
        super.onCreate()
        Dbg.log("service onCreate")
    }

    override fun onDestroy() {
        Dbg.log("service onDestroy")
        super.onDestroy()
    }

    override fun onCreateEngine(): Engine {
        Dbg.log("onCreateEngine")
        return DropEngine()
    }

    private inner class DropEngine : Engine() {
        private var r: DropRenderer? = null

        override fun onCreate(holder: SurfaceHolder) {
            super.onCreate(holder)
            Dbg.log("engine onCreate preview=$isPreview")
            try {
                r = DropRenderer(applicationContext) { drawNow() }
                setTouchEventsEnabled(true)
            } catch (t: Throwable) {
                Dbg.log("renderer init failed", t)
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder) {
            Dbg.log("surfaceCreated")
        }

        override fun onSurfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
            Dbg.log("surfaceChanged ${width}x$height")
            r?.markFull()
            try { r?.setSize(width, height) } catch (t: Throwable) { Dbg.log("setSize failed", t) }
            drawNow()
        }

        override fun onSurfaceRedrawNeeded(holder: SurfaceHolder) {
            r?.markFull()
            drawNow()
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder) {
            Dbg.log("surfaceDestroyed")
        }

        override fun onVisibilityChanged(visible: Boolean) {
            Dbg.log("engine visible=$visible")
            try { r?.setVisible(visible) } catch (t: Throwable) { Dbg.log("setVisible failed", t) }
            if (visible) drawNow()
        }

        override fun onTouchEvent(event: MotionEvent) {
            r?.onTouch(event)
        }

        // launcher page swipes make the object lag behind (works on home screens that scroll the wallpaper)
        override fun onOffsetsChanged(xOffset: Float, yOffset: Float, xStep: Float, yStep: Float, xPix: Int, yPix: Int) {
            try { r?.scrolled(xOffset) } catch (t: Throwable) { Dbg.log("scroll failed", t) }
        }

        // launchers forward home-screen taps as commands instead of touch events
        override fun onCommand(action: String?, x: Int, y: Int, z: Int, extras: Bundle?, resultRequested: Boolean): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP) {
                try { r?.poke(x.toFloat(), y.toFloat()) } catch (t: Throwable) { Dbg.log("tap failed", t) }
            }
            return null
        }

        override fun onDestroy() {
            Dbg.log("engine onDestroy")
            try { r?.release() } catch (t: Throwable) { Dbg.log("release failed", t) }
            r = null
            super.onDestroy()
        }

        /** Moving frames only repaint the painted area's bounding box (dirty rect); everything else a full frame. */
        private fun drawNow() {
            val holder = surfaceHolder
            var c: Canvas? = null
            try {
                val rend = r
                val want = rend?.dirtyRect()
                val dirty = if (want != null) Rect(want) else null
                c = if (dirty != null) holder.lockCanvas(dirty) else holder.lockCanvas()
                if (c == null) { Dbg.log("lockCanvas returned null"); return }
                // the system may enlarge the dirty rect (e.g. after a resize) -> then draw everything
                val full = dirty == null || dirty != want
                rend?.draw(c, full)
            } catch (t: Throwable) {
                Dbg.log("drawNow failed", t)
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c) } catch (t: Throwable) { Dbg.log("unlockCanvasAndPost failed", t) }
                }
            }
        }
    }
}
