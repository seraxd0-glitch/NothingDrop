package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.IOException
import java.io.OutputStream
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** Saves the chosen photo + mask + settings so the wallpaper service can read them. */
object Store {
    @Volatile var error: String? = null

    fun prefs(c: Context) = c.getSharedPreferences("nd", Context.MODE_PRIVATE)
    private fun img(c: Context) = File(c.filesDir, "photo.img")
    private fun msk(c: Context) = File(c.filesDir, "mask.gz")

    /** Write to a temp file first so the wallpaper never reads a half-written file. */
    private fun atomic(dst: File, write: (OutputStream) -> Unit) {
        val tmp = File(dst.path + ".tmp")
        tmp.outputStream().use(write)
        if (!tmp.renameTo(dst)) {
            dst.delete()
            if (!tmp.renameTo(dst)) throw IOException("rename failed: ${dst.name}")
        }
    }

    /** Photo + mask only; settings are written by the UI (prefs). Bumping "rev" tells the wallpaper to reload. */
    fun save(c: Context, bmp: Bitmap, mask: ByteArray) {
        val fmt = if (bmp.hasAlpha()) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG
        atomic(img(c)) { if (!bmp.compress(fmt, 92, it)) throw IOException("compress failed") }
        atomic(msk(c)) { o ->
            DataOutputStream(GZIPOutputStream(o)).use {
                it.writeInt(bmp.width); it.writeInt(bmp.height); it.write(mask)
            }
        }
        prefs(c).edit().putLong("rev", System.nanoTime()).commit()
    }

    fun load(c: Context): Pair<Bitmap, ByteArray>? {
        try {
            val bmp = BitmapFactory.decodeFile(img(c).path)
            if (bmp == null) { error = "No saved photo found"; return null }
            DataInputStream(GZIPInputStream(msk(c).inputStream())).use {
                val w = it.readInt(); val h = it.readInt()
                if (w != bmp.width || h != bmp.height) { error = "Mask size mismatch"; return null }
                val m = ByteArray(w * h); it.readFully(m)
                return bmp to m
            }
        } catch (e: Exception) {
            error = e.toString()
            Dbg.log("Store.load failed", e)
            return null
        }
    }
}
