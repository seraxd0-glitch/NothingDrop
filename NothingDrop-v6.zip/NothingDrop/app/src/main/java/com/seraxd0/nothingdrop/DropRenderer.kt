package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Debug
import android.os.HandlerThread
import android.os.Looper
import android.os.Process
import android.os.SystemClock
import android.view.Choreographer
import android.view.MotionEvent
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.exp
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tanh

/**
 * Soft-body jiggle renderer shared by the live wallpaper, the in-app live preview and the Test screen.
 *
 * Physics: every grid node inside the painted area is a damped spring (anchored more strongly near the
 * mask edge) coupled to its 4 neighbours, so taps make ripples, shakes make far parts lag/overshoot and
 * fingers can grab and drag separate parts of the jelly (up to 3 at once).
 * Speed: only the bounding box of the painted area is simulated and redrawn (dirty rect), frames are only
 * produced while something moves, FPS is capped by a setting, nothing is allocated per frame.
 * Threads: with background=true (wallpaper) all physics + drawing run on a private render thread, so touch,
 * sensors and the system UI never wait for a frame; every public method can be called from any thread.
 * Stability: the scene is built on a worker thread; draw() never throws.
 */
class DropRenderer(
    ctx: Context,
    background: Boolean,
    private val rateHint: ((Float) -> Unit)?,
    private val redraw: () -> Unit
) : SensorEventListener {
    private class Scene(
        val full: Bitmap, val region: Bitmap, val rect: Rect,
        val px0: Int, val py0: Int, val rc: Int, val rr: Int,
        val base: FloatArray, val verts: FloatArray,
        val w: FloatArray, val ka: FloatArray, val sq: FloatArray, val rad: FloatArray,
        val act: IntArray, val nb: IntArray,
        val dx: FloatArray, val dy: FloatArray, val vx: FloatArray, val vy: FloatArray,
        val ax: FloatArray, val ay: FloatArray, val cx: Float, val cy: Float
    )

    /** One finger that is dragging the jelly (or just being tracked for tap detection). */
    private class Grab {
        var id = -1
        var x0 = 0f
        var y0 = 0f
        var tx = 0f
        var ty = 0f
        var t0 = 0L
        var moved = 0f
        var n = 0
        var idx = IntArray(0)
        var f = FloatArray(0)
    }

    private val app = ctx.applicationContext
    private val sm = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val thread: HandlerThread? =
        if (background) HandlerThread("nd-render", Process.THREAD_PRIORITY_DISPLAY).also { it.start() } else null
    private val looper: Looper = thread?.looper ?: Looper.getMainLooper()
    private val main = Handler(looper) // every renderer task runs on this looper
    private var W = 0
    private var H = 0
    private var visible = false
    private var running = false
    private var dead = false
    private var loading = false
    private var gen = 0
    private var key = ""
    private var scene: Scene? = null
    private var err: String? = null
    private var needFull = true

    // settings (see applySettings)
    private var maxPx = 0f
    private var zeta = 0.3f
    private var om0 = 10f
    private var kn = 600f
    private var kd = 20f
    private var spread = 0.6f
    private var tiltGain = 1f
    private var shakeGain = 1f
    private var touchGain = 1f
    private var idleAmp = 0f
    private var frameNs = 16_666_667L
    private var passes = 3
    private var touchOn = true
    private var invert = false
    private var axX = 1f
    private var axY = 1f
    private var alphaFast = 0.13f
    private var alphaSlow = 0.01f
    private var kickThr = 1.5f
    private var dragOn = true
    private var maxFingers = 2
    private var grabR = 300f
    private var dragReachPx = 150f
    private var grabW = 20f
    private var quality = 1
    private var marginFrac = 0.15f

    // dynamic state
    private var tgtX = 0f
    private var tgtY = 0f
    private var curTX = 0f
    private var curTY = 0f
    private var settledTX = 0f
    private var settledTY = 0f
    private var simT = 0f
    private var maxD = 0f
    private var maxV = 0f
    private var maxE = 0f
    private val g = FloatArray(3)
    private val gs = FloatArray(3)
    private var haveG = false
    private var lastNs = 0L
    private var lastSensor = 0L
    private var lastPoke = 0L
    private var firstFrame = true
    private var perfN = 0
    private var perfSum = 0L
    private val grabs = Array(3) { Grab() }
    private var holding = 0
    private var lastTouchNs = 0L
    private var touchLogged = false
    private var tapLogged = false
    private var animating = false
    private var lastCb = 0L
    private var vsyncNs = 16_666_667L
    private var cpuNs = 0L
    private var quietUntil = 0L

    /** Run on the render looper (immediately if already there). */
    private fun post(block: () -> Unit) {
        if (Looper.myLooper() == looper) {
            try { block() } catch (t: Throwable) { Dbg.log("render task failed", t) }
        } else {
            main.post { try { block() } catch (t: Throwable) { Dbg.log("render task failed", t) } }
        }
    }

    private val frame = Choreographer.FrameCallback { t ->
        running = false
        if (visible && !dead) {
            try {
                // measure the real vsync period (it changes with the 60/90/120 Hz refresh modes)
                if (lastCb != 0L) {
                    val d = t - lastCb
                    if (d in 3_000_000L..50_000_000L) vsyncNs = (vsyncNs * 9 + d) / 10
                }
                lastCb = t
                var interval = if (idleAmp > 0f) max(frameNs, 33_000_000L) else frameNs
                interval = max(interval, cpuNs * 13 / 10) // never ask for more frames than this phone can compute
                if (lastNs != 0L && t - lastNs < interval - vsyncNs / 2) {
                    go() // too early for the FPS cap: wait for the next vsync
                } else {
                    val dt = if (lastNs == 0L) 0.016f else ((t - lastNs) / 1e9f).coerceIn(0.001f, 0.05f)
                    lastNs = t
                    simT += dt
                    val c0 = Debug.threadCpuTimeNanos()
                    step(dt)
                    redraw()
                    cpuNs = (cpuNs * 7 + (Debug.threadCpuTimeNanos() - c0)) / 8
                    if (settled()) {
                        lastNs = 0; settledTX = curTX; settledTY = curTY
                        if (animating) { animating = false; hint(0f) }
                    } else go()
                }
            } catch (e: Throwable) {
                Dbg.log("frame failed", e)
            }
        }
    }

    /** Ask the system for a refresh rate while we animate (0 = no preference when idle). */
    private fun hint(hz: Float) {
        try { rateHint?.invoke(hz) } catch (t: Throwable) { Dbg.log("rate hint failed", t) }
    }

    private fun go() {
        if (!running && visible && !dead) {
            running = true
            if (!animating) {
                animating = true
                val f = 1e9f / frameNs
                hint(if (idleAmp > 0f) min(f, 30f) else f)
            }
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun settled() = scene == null || (idleAmp == 0f && maxV < 1f && maxE < 0.25f && holding == 0)

    // ------------------------------------------------------------ lifecycle

    fun setSize(w: Int, h: Int) = post { setSizeImpl(w, h) }

    private fun setSizeImpl(w: Int, h: Int) {
        if (dead || w <= 0 || h <= 0 || (w == W && h == H)) return
        W = w; H = h
        Dbg.log("surface size ${w}x$h")
        reload(true)
    }

    /** Re-read settings; rebuilds the scene only if the photo/mask/edge-softness/quality changed. */
    fun refresh() = post { reload(false) }

    fun markFull() = post { needFull = true }

    /** Redraw soon (async). */
    fun requestRedraw() = post { redraw() }

    /** Redraw and wait (max 150 ms) - used when the system asks for a frame right now. */
    fun redrawSync() {
        if (Looper.myLooper() == looper) { redraw(); return }
        val latch = java.util.concurrent.CountDownLatch(1)
        val ok = main.post {
            try { redraw() } catch (t: Throwable) { Dbg.log("redraw failed", t) }
            latch.countDown()
        }
        if (!ok) return
        try { latch.await(150, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (e: InterruptedException) { }
    }

    /** Region to redraw for a moving frame, or null when the whole surface must be drawn. */
    fun dirtyRect(): Rect? {
        val s = scene ?: return null
        return if (needFull) null else s.rect
    }

    fun setVisible(v: Boolean) = post { setVisibleImpl(v) }

    private fun setVisibleImpl(v: Boolean) {
        if (dead || v == visible) return
        visible = v
        Dbg.log("visible=$v")
        if (v) {
            reload(false)
            needFull = true
            haveG = false; lastNs = 0; lastSensor = 0; lastCb = 0
            quietUntil = SystemClock.elapsedRealtimeNanos() + 700_000_000L // ignore the unlock / pick-up motion
            try {
                if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME, main)
                else Dbg.log("no accelerometer: tilt/shake disabled")
            } catch (e: Throwable) {
                Dbg.log("sensor register failed", e)
            }
            redraw()
            if (idleAmp > 0f) go()
        } else {
            try { sm.unregisterListener(this) } catch (e: Throwable) { }
            Choreographer.getInstance().removeFrameCallback(frame)
            running = false
            releaseGrabs()
            if (animating) { animating = false; hint(0f) }
        }
    }

    fun release() = post { releaseImpl(); thread?.quitSafely() }

    private fun releaseImpl() {
        dead = true
        try { sm.unregisterListener(this) } catch (e: Throwable) { }
        Choreographer.getInstance().removeFrameCallback(frame)
        if (animating) { animating = false; hint(0f) }
        scene = null
        Dbg.log("renderer released")
    }

    private fun applySettings(): String {
        val sp = Store.prefs(app)
        fun i(k: String, d: Int) = sp.getInt(k, d)
        maxPx = (0.01f + 0.05f * i("strength", 50) / 100f) * W
        zeta = 0.9f - 0.82f * i("elasticity", 60) / 100f
        om0 = 5f + 11f * i("stiffness", 50) / 100f
        val j = i("jelly", 50) / 100f
        kn = 1200f * (1f - 0.85f * j)
        kd = 0.8f * sqrt(2f * kn)
        spread = 1.2f * j
        tiltGain = i("tilt", 50) / 50f
        shakeGain = i("shake", 50) / 50f
        touchGain = i("touchForce", 50) / 50f
        idleAmp = i("idle", 0) / 100f * maxPx * 0.35f
        axX = i("axisX", 50) / 50f
        axY = i("axisY", 50) / 50f
        alphaFast = 0.03f + 0.25f * (1f - i("tiltSmooth", 60) / 100f)
        val rcv = i("recenter", 50) / 100f
        alphaSlow = if (rcv == 0f) 0f else 0.002f + 0.03f * rcv * rcv
        kickThr = 3.5f - 3.0f * i("shakeSens", 65) / 100f
        frameNs = (1e9f / i("fps", 60).coerceIn(15, 240)).toLong()
        passes = 1 + i("feather", 50) * 5 / 100
        quality = i("quality", 1).coerceIn(0, 2)
        touchOn = sp.getBoolean("touch", true)
        invert = sp.getBoolean("invert", false)
        dragOn = sp.getBoolean("drag", true)
        maxFingers = i("fingers", 2).coerceIn(1, 3)
        val reach = 0.04f + 0.2f * i("dragReach", 50) / 100f
        dragReachPx = if (dragOn) reach * W else 0f
        grabR = (0.06f + 0.4f * i("grabRadius", 50) / 100f) * min(W, H)
        grabW = 10f + 20f * i("grabFirm", 50) / 100f
        // region margin must cover the largest possible displacement (tilt/shake or drag); quantised so sliders don't force rebuilds
        marginFrac = ceil(max(0.132f, if (dragOn) reach * 1.3f else 0f) * 20f) / 20f
        return "${sp.getLong("rev", 0)}|$passes|$quality|$marginFrac"
    }

    private fun reload(force: Boolean) {
        if (dead || W == 0 || H == 0) return
        val k = applySettings()
        if (!force && k == key && (scene != null || loading)) return
        key = k
        val id = ++gen
        val w = W
        val h = H
        val ps = passes
        val q = quality
        val mf = marginFrac
        loading = true
        Dbg.log("reload start ${w}x$h key=$k")
        Thread({
            try {
                val s = build(w, h, ps, q, mf)
                main.post {
                    if (!dead && id == gen) {
                        scene = s; err = null; loading = false; needFull = true
                        maxD = 0f; maxV = 0f; maxE = 0f; settledTX = 0f; settledTY = 0f
                        releaseGrabs()
                        redraw()
                        if (idleAmp > 0f) go()
                    }
                }
            } catch (t: Throwable) {
                Dbg.log("scene build failed", t)
                main.post {
                    if (!dead && id == gen) {
                        scene = null; loading = false
                        err = "${t.javaClass.simpleName}: ${t.message}"
                        redraw()
                    }
                }
            }
        }, "nd-build").start()
    }

    // ------------------------------------------------------------ scene

    private fun build(sw: Int, sh: Int, passes: Int, quality: Int, marginFrac: Float): Scene {
        val t0 = System.nanoTime()
        val (photo, m) = Store.load(app) ?: throw IllegalStateException(Store.error ?: "No saved photo")
        val pw = photo.width
        val ph = photo.height
        if (m.none { it.toInt() != 0 }) throw IllegalStateException("Saved mask is empty")
        val cell = max(14, sw / (if (quality == 0) 30 else if (quality == 2) 64 else 45))
        val cols = (sw + cell - 1) / cell
        val rows = (sh + cell - 1) / cell
        val bw = cols * cell
        val bh = rows * cell
        val sc = max(bw.toFloat() / pw, bh.toFloat() / ph)
        val dw = pw * sc
        val dh = ph * sc
        val full = Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888)
        Canvas(full).apply {
            drawColor(Color.BLACK)
            drawBitmap(photo, null, RectF((bw - dw) / 2, (bh - dh) / 2, (bw + dw) / 2, (bh + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        photo.recycle()

        // mask weight per grid node (5 samples), then soften the edge
        val ox = (dw - bw) / 2
        val oy = (dh - bh) / 2
        val nc = cols + 1
        val wt = FloatArray(nc * (rows + 1))
        fun at(x: Float, y: Float): Float {
            val i = ((x + ox) / sc).toInt().coerceIn(0, pw - 1)
            val j = ((y + oy) / sc).toInt().coerceIn(0, ph - 1)
            return (m[j * pw + i].toInt() and 255) / 255f
        }
        val hf = cell / 2f
        for (j in 0..rows) for (i in 0..cols) {
            val x = (i * cell).toFloat()
            val y = (j * cell).toFloat()
            wt[j * nc + i] = (2 * at(x, y) + at(x - hf, y - hf) + at(x + hf, y - hf) +
                at(x - hf, y + hf) + at(x + hf, y + hf)) / 6
        }
        repeat(passes) { blur(wt, nc, rows + 1) }

        // fade near the screen border; bounding box of the active nodes
        var i0 = cols; var i1 = -1; var j0 = rows; var j1 = -1
        for (j in 0..rows) for (i in 0..cols) {
            val k = j * nc + i
            wt[k] *= min(1f, min(min(i, cols - i), min(j, rows - j)) / 3f)
            if (wt[k] > 0.003f) {
                if (i < i0) i0 = i
                if (i > i1) i1 = i
                if (j < j0) j0 = j
                if (j > j1) j1 = j
            }
        }
        if (i1 < 0) throw IllegalStateException("Painted area too small")

        // region = bounding box + margin big enough for the largest possible displacement
        val margin = ceil(marginFrac * sw / cell).toInt() + 2
        val c0 = max(0, i0 - margin)
        val c1 = min(cols, i1 + margin)
        val r0 = max(0, j0 - margin)
        val r1 = min(rows, j1 + margin)
        val rc = c1 - c0
        val rr = r1 - r0
        if (rc < 1 || rr < 1) throw IllegalStateException("Region too small")
        val rn = rc + 1
        val n = rn * (rr + 1)
        val base = FloatArray(n * 2)
        val w = FloatArray(n + 1)
        val ka = FloatArray(n + 1)
        val sq = FloatArray(n + 1)
        val rad = FloatArray(n + 1)
        val list = ArrayList<Int>()
        var aw = 0f
        var ax = 0f
        var ay = 0f
        for (j in 0..rr) for (i in 0..rc) {
            val k = j * rn + i
            base[2 * k] = ((c0 + i) * cell).toFloat()
            base[2 * k + 1] = ((r0 + j) * cell).toFloat()
            val wk = wt[(r0 + j) * nc + (c0 + i)]
            if (wk > 0.003f) {
                w[k] = wk
                ka[k] = 0.35f + 5f * (1f - wk) * (1f - wk)
                sq[k] = sqrt(ka[k])
                list.add(k)
                aw += wk; ax += wk * base[2 * k]; ay += wk * base[2 * k + 1]
            }
        }
        val cx = if (aw > 0) ax / aw else sw / 2f
        val cy = if (aw > 0) ay / aw else sh / 2f
        var md = 1f
        for (k in list) md = max(md, hypot(base[2 * k] - cx, base[2 * k + 1] - cy))
        for (k in list) rad[k] = hypot(base[2 * k] - cx, base[2 * k + 1] - cy) / md
        val act = list.toIntArray()
        val nb = IntArray(act.size * 4)
        for (a in act.indices) {
            val k = act[a]
            val i = k % rn
            val j = k / rn
            nb[4 * a] = if (i > 0) k - 1 else n
            nb[4 * a + 1] = if (i < rc) k + 1 else n
            nb[4 * a + 2] = if (j > 0) k - rn else n
            nb[4 * a + 3] = if (j < rr) k + rn else n
        }
        val region = Bitmap.createBitmap(full, c0 * cell, r0 * cell, rc * cell, rr * cell)
        val rect = Rect(c0 * cell, r0 * cell, c1 * cell, r1 * cell)
        if (!rect.intersect(0, 0, sw, sh)) rect.set(0, 0, sw, sh)
        Dbg.log(
            "scene built ${sw}x$sh photo=${pw}x$ph cell=$cell region=${rc}x$rr of ${cols}x$rows " +
                "active=${act.size} passes=$passes quality=$quality in ${(System.nanoTime() - t0) / 1_000_000}ms"
        )
        return Scene(
            full, region, rect, c0 * cell, r0 * cell, rc, rr, base, base.copyOf(),
            w, ka, sq, rad, act, nb,
            FloatArray(n + 1), FloatArray(n + 1), FloatArray(n + 1), FloatArray(n + 1),
            FloatArray(n + 1), FloatArray(n + 1), cx, cy
        )
    }

    private fun blur(a: FloatArray, w: Int, h: Int) {
        val o = FloatArray(a.size)
        for (j in 0 until h) for (i in 0 until w) {
            var s = 0f
            for (dj in -1..1) for (di in -1..1)
                s += a[(j + dj).coerceIn(0, h - 1) * w + (i + di).coerceIn(0, w - 1)]
            o[j * w + i] = s / 9
        }
        o.copyInto(a)
    }

    // ------------------------------------------------------------ drawing

    /** full=false: only the dirty region is on the canvas (clip already set by lockCanvas). */
    fun draw(c: Canvas, full: Boolean = true) {
        val t0 = System.nanoTime()
        try {
            val s = scene
            if (s == null) {
                c.drawColor(0xFF111318.toInt())
                note(c, err ?: if (loading) "Loading…" else "Nothing saved yet. Open NothingDrop, paint an area and tap Set wallpaper.")
                needFull = true
                return
            }
            if (full) { c.drawBitmap(s.full, 0f, 0f, null); needFull = false }
            if (maxD >= 0.02f) c.drawBitmapMesh(s.region, s.rc, s.rr, s.verts, 0, null, 0, null)
            else if (!full) c.drawBitmap(s.region, s.px0.toFloat(), s.py0.toFloat(), null)
            if (firstFrame) { firstFrame = false; Dbg.log("first frame drawn ${c.width}x${c.height}") }
            perfSum += System.nanoTime() - t0
            if (++perfN >= 180) {
                Dbg.log("perf: avg draw ${perfSum / perfN / 1000}us over $perfN frames, cpu/frame ${cpuNs / 1000}us, vsync ${vsyncNs / 1000}us, region ${s.rect.width()}x${s.rect.height()}")
                perfN = 0; perfSum = 0
            }
        } catch (t: Throwable) {
            Dbg.log("draw failed", t)
            try { c.drawColor(0xFF111318.toInt()); note(c, "draw: $t"); needFull = true } catch (e: Throwable) { }
        }
    }

    private fun note(c: Canvas, msg: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = c.width / 26f }
        var yy = c.height / 2f
        for (line in msg.chunked(30)) {
            c.drawText(line, 40f, yy, p)
            yy += p.textSize * 1.3f
        }
    }

    // ------------------------------------------------------------ physics

    private fun step(dt: Float) {
        val s = scene ?: return
        val sub = min(4, max(1, ceil(dt / 0.0085f).toInt()))
        val h = dt / sub
        val om2 = om0 * om0
        val cd = 2f * zeta * om0
        val tX = tgtX + if (idleAmp > 0f) idleAmp * sin(simT * 1.2f) else 0f
        val tY = tgtY + if (idleAmp > 0f) idleAmp * sin(simT * 0.83f + 1.3f) else 0f
        curTX = tX; curTY = tY
        val lim = max(maxPx * 2.2f, dragReachPx * 1.25f)
        val act = s.act; val nb = s.nb; val w = s.w; val ka = s.ka; val sq = s.sq
        val dx = s.dx; val dy = s.dy; val vx = s.vx; val vy = s.vy; val ax = s.ax; val ay = s.ay
        var mv = 0f; var me = 0f; var mdis = 0f
        repeat(sub) {
            for (a in act.indices) {
                val k = act[a]
                val b = a * 4
                val n0 = nb[b]; val n1 = nb[b + 1]; val n2 = nb[b + 2]; val n3 = nb[b + 3]
                val kk = om2 * ka[k]
                val c = cd * sq[k]
                val avx = (dx[n0] + dx[n1] + dx[n2] + dx[n3]) * 0.25f
                val avy = (dy[n0] + dy[n1] + dy[n2] + dy[n3]) * 0.25f
                val avvx = (vx[n0] + vx[n1] + vx[n2] + vx[n3]) * 0.25f
                val avvy = (vy[n0] + vy[n1] + vy[n2] + vy[n3]) * 0.25f
                ax[k] = kk * (w[k] * tX - dx[k]) - c * vx[k] + kn * (avx - dx[k]) + kd * (avvx - vx[k])
                ay[k] = kk * (w[k] * tY - dy[k]) - c * vy[k] + kn * (avy - dy[k]) + kd * (avvy - vy[k])
            }
            if (holding > 0) { // fingers holding the jelly: springs pulling the grabbed nodes toward each finger
                val kg = grabW * grabW
                val cg = 1.6f * grabW
                for (gr in grabs) {
                    if (gr.id == -1 || gr.n == 0) continue
                    for (q in 0 until gr.n) {
                        val k = gr.idx[q]
                        val f = gr.f[q]
                        ax[k] += f * (kg * (f * gr.tx - dx[k]) - cg * vx[k])
                        ay[k] += f * (kg * (f * gr.ty - dy[k]) - cg * vy[k])
                    }
                }
            }
            mv = 0f; me = 0f; mdis = 0f
            for (a in act.indices) {
                val k = act[a]
                vx[k] += ax[k] * h
                vy[k] += ay[k] * h
                dx[k] = (dx[k] + vx[k] * h).coerceIn(-lim, lim)
                dy[k] = (dy[k] + vy[k] * h).coerceIn(-lim, lim)
                val v = abs(vx[k]) + abs(vy[k])
                if (v > mv) mv = v
                val e = abs(w[k] * tX - dx[k]) + abs(w[k] * tY - dy[k])
                if (e > me) me = e
                val d = abs(dx[k]) + abs(dy[k])
                if (d > mdis) mdis = d
            }
        }
        maxV = mv; maxE = me; maxD = mdis
        val vt = s.verts; val bs = s.base
        for (k in act) { vt[2 * k] = bs[2 * k] + dx[k]; vt[2 * k + 1] = bs[2 * k + 1] + dy[k] }
    }

    /** Impulse on every node, stronger for nodes far from the centre (they swing/lag more). */
    private fun kickAll(ix: Float, iy: Float) {
        val s = scene ?: return
        val vm = maxPx * 20
        for (k in s.act) {
            val f = s.w[k] * (1f + spread * s.rad[k])
            s.vx[k] = (s.vx[k] + ix * f).coerceIn(-vm, vm)
            s.vy[k] = (s.vy[k] + iy * f).coerceIn(-vm, vm)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        try {
            val a = e.values
            if (!haveG) { for (i in 0..2) { g[i] = a[i]; gs[i] = a[i] }; haveG = true }
            for (i in 0..2) { g[i] += alphaFast * (a[i] - g[i]); gs[i] += alphaSlow * (a[i] - gs[i]) }
            if (SystemClock.elapsedRealtimeNanos() < quietUntil) { // just woke up: let the filters settle, no kicks
                for (i in 0..2) gs[i] = g[i]
                return
            }
            // tilt: the object slides "downhill" relative to how the phone was being held
            val kt = maxPx / 4.9f * tiltGain * (if (invert) -1f else 1f)
            val lim = maxPx * 2f
            tgtX = (-(g[0] - gs[0]) * kt * axX).coerceIn(-lim, lim)
            tgtY = ((g[1] - gs[1]) * kt * axY).coerceIn(-lim, lim)
            // shake: inertia kick opposite to the phone's own acceleration
            val dt = if (lastSensor == 0L) 0.02f else ((e.timestamp - lastSensor) / 1e9f).coerceIn(0.005f, 0.05f)
            lastSensor = e.timestamp
            val lx = a[0] - g[0]
            val ly = a[1] - g[1]
            val kick = abs(lx) + abs(ly) > kickThr
            if (kick) {
                val gain = maxPx * 6 * dt * shakeGain
                kickAll(-lx * gain * axX, ly * gain * axY)
            }
            if (scene != null && (kick || abs(tgtX - settledTX) > 0.5f || abs(tgtY - settledTY) > 0.5f)) go()
        } catch (t: Throwable) {
            Dbg.log("sensor failed", t)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    /** Tap: whole object is pushed away from the finger and a ripple spreads from the touch point. */
    private fun poke(px: Float, py: Float) {
        val s = scene ?: return
        val now = System.nanoTime()
        if (!touchOn || !visible || now - lastPoke < 120_000_000L) return
        lastPoke = now
        val v0 = maxPx * om0 * 1.2f * touchGain
        val sig = 0.3f * max(W, H)
        val vm = maxPx * 20
        val gx = s.cx - px
        val gy = s.cy - py
        val gd = hypot(gx, gy).coerceAtLeast(1f)
        for (k in s.act) {
            val ddx = s.base[2 * k] + s.dx[k] - px
            val ddy = s.base[2 * k + 1] + s.dy[k] - py
            val d = hypot(ddx, ddy).coerceAtLeast(1f)
            val q = d / sig
            val f = exp(-q * q) * s.w[k] * v0
            val ux = 0.6f * gx / gd + 0.4f * ddx / d
            val uy = 0.6f * gy / gd + 0.4f * ddy / d
            s.vx[k] = (s.vx[k] + ux * f).coerceIn(-vm, vm)
            s.vy[k] = (s.vy[k] + uy * f).coerceIn(-vm, vm)
        }
        go()
    }

    // ------------------------------------------------------------ touch / multi-finger drag

    private fun slot(id: Int): Grab? {
        for (gr in grabs) if (gr.id == id) return gr
        return null
    }

    private fun releaseGrabs() {
        for (gr in grabs) { gr.id = -1; gr.n = 0 }
        holding = 0
    }

    /** Feed raw touch events from any thread (they are copied: MotionEvents get recycled). Up to 3 fingers drag separately. */
    fun onMotion(ev: MotionEvent) {
        val n = min(ev.pointerCount, 10)
        val act = ev.actionMasked
        val ai = ev.actionIndex
        val ids = IntArray(n) { ev.getPointerId(it) }
        val xs = FloatArray(n) { ev.getX(it) }
        val ys = FloatArray(n) { ev.getY(it) }
        post { handleMotion(act, ai, ids, xs, ys) }
    }

    private fun handleMotion(act: Int, ai: Int, ids: IntArray, xs: FloatArray, ys: FloatArray) {
        if (!touchLogged) { touchLogged = true; Dbg.log("touch events arriving (drag possible here), pointers=${ids.size}") }
        when (act) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> if (ai < ids.size) touchDown(ids[ai], xs[ai], ys[ai])
            MotionEvent.ACTION_MOVE -> for (i in ids.indices) touchMove(ids[i], xs[i], ys[i])
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> if (ai < ids.size) touchUp(ids[ai])
            MotionEvent.ACTION_CANCEL -> { releaseGrabs(); go() }
        }
    }

    /** Home-screen tap forwarded by the launcher as a command (it sends no touch stream). */
    fun tapCommand(x: Float, y: Float) = post { tapImpl(x, y) }

    private fun tapImpl(x: Float, y: Float) {
        if (System.nanoTime() - lastTouchNs < 700_000_000L) return
        if (!tapLogged) { tapLogged = true; Dbg.log("tap command received (launcher forwards taps only)") }
        poke(x, y)
    }

    private fun touchDown(id: Int, x: Float, y: Float) {
        val s = scene ?: return
        lastTouchNs = System.nanoTime()
        if (!visible || slot(id) != null) return
        var free: Grab? = null
        var used = 0
        for (gr in grabs) { if (gr.id == -1) { if (free == null) free = gr } else used++ }
        val gr = free ?: return
        if (used >= maxFingers) return
        gr.id = id; gr.x0 = x; gr.y0 = y; gr.tx = 0f; gr.ty = 0f; gr.moved = 0f; gr.t0 = lastTouchNs; gr.n = 0
        if (dragOn) {
            if (gr.idx.size < s.act.size) { gr.idx = IntArray(s.act.size); gr.f = FloatArray(s.act.size) }
            val inv = 1f / (grabR * grabR)
            var n = 0
            var best = 0f
            for (k in s.act) {
                val ddx = s.base[2 * k] + s.dx[k] - x
                val ddy = s.base[2 * k + 1] + s.dy[k] - y
                val q = (ddx * ddx + ddy * ddy) * inv
                if (q < 6f) {
                    val f = exp(-q) * min(1f, s.w[k] * 1.5f)
                    if (f > 0.02f) { gr.idx[n] = k; gr.f[n] = f; n++; if (f > best) best = f }
                }
            }
            if (best >= 0.2f) { gr.n = n; holding++ } // touches on empty background don't grab
        }
        go()
    }

    private fun touchMove(id: Int, x: Float, y: Float) {
        val gr = slot(id) ?: return
        val dx = x - gr.x0
        val dy = y - gr.y0
        val d = hypot(dx, dy)
        if (d > gr.moved) gr.moved = d
        if (gr.n > 0 && dragReachPx > 1f) {
            // rubber band: follows the finger 1:1 at first, then resists near the reach limit
            val k = if (d > 0.01f) dragReachPx * tanh(d / dragReachPx) / d else 1f
            gr.tx = dx * k; gr.ty = dy * k
            go()
        }
    }

    private fun touchUp(id: Int) {
        val gr = slot(id) ?: return
        val tap = System.nanoTime() - gr.t0 < 220_000_000L && gr.moved < 0.03f * min(W, H)
        val x0 = gr.x0
        val y0 = gr.y0
        if (gr.n > 0 && holding > 0) holding--
        gr.id = -1; gr.n = 0
        if (tap) poke(x0, y0)
        go() // released: it keeps its velocity and springs back with a jiggle
    }
}
