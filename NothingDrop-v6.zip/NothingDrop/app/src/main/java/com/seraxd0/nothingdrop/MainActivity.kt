package com.seraxd0.nothingdrop

import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private class Choice(val key: String, val group: Int, val btn: IntArray, val vals: IntArray, val def: Int)

    private lateinit var mask: MaskView
    private lateinit var live: LiveView
    private lateinit var status: TextView
    private lateinit var panePaint: View
    private lateinit var panePhysics: View
    private val sl = LinkedHashMap<String, Slider>()
    private val sw = LinkedHashMap<String, MaterialSwitch>()
    private val choice = HashMap<String, Int>()
    private var resetting = false

    private val sliderIds = linkedMapOf(
        "strength" to R.id.s_strength, "elasticity" to R.id.s_elasticity, "stiffness" to R.id.s_stiffness,
        "jelly" to R.id.s_jelly, "axisX" to R.id.s_axisX, "axisY" to R.id.s_axisY, "idle" to R.id.s_idle,
        "tilt" to R.id.s_tilt, "tiltSmooth" to R.id.s_tiltSmooth, "recenter" to R.id.s_recenter,
        "shake" to R.id.s_shake, "shakeSens" to R.id.s_shakeSens,
        "grabRadius" to R.id.s_grabRadius, "dragReach" to R.id.s_dragReach, "grabFirm" to R.id.s_grabFirm,
        "touchForce" to R.id.s_touchForce, "feather" to R.id.s_feather
    )
    private val sliderDefs = mapOf("elasticity" to 60, "idle" to 0, "tiltSmooth" to 60, "shakeSens" to 65) // others 50
    private val switchIds = linkedMapOf("touch" to R.id.touch, "drag" to R.id.drag, "invert" to R.id.invert)
    private val switchDefs = mapOf("touch" to true, "drag" to true, "invert" to false)
    private val choices = listOf(
        Choice("fps", R.id.fpsGroup, intArrayOf(R.id.f30, R.id.f60, R.id.f90, R.id.f120), intArrayOf(30, 60, 90, 120), 60),
        Choice("quality", R.id.qualGroup, intArrayOf(R.id.q0, R.id.q1, R.id.q2), intArrayOf(0, 1, 2), 1),
        Choice("fingers", R.id.fingGroup, intArrayOf(R.id.n1, R.id.n2, R.id.n3), intArrayOf(1, 2, 3), 2)
    )
    private val presetKeys = listOf("strength", "elasticity", "stiffness", "jelly", "tilt", "shake")
    private val presets = mapOf(
        R.id.pSubtle to intArrayOf(25, 35, 70, 20, 50, 40),
        R.id.pNatural to intArrayOf(50, 60, 50, 50, 50, 50),
        R.id.pJelly to intArrayOf(65, 75, 35, 85, 50, 60),
        R.id.pBouncy to intArrayOf(80, 90, 45, 60, 60, 70)
    )

    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) load(uri)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        mask = findViewById(R.id.mask)
        live = findViewById(R.id.live)
        status = findViewById(R.id.status)
        panePaint = findViewById(R.id.panePaint)
        panePhysics = findViewById(R.id.panePhysics)

        // saved settings -> controls (listeners are added afterwards so this doesn't write anything back)
        val sp = Store.prefs(this)
        for ((k, id) in sliderIds) {
            val s = findViewById<Slider>(id)
            s.value = sp.getInt(k, sliderDefs[k] ?: 50).toFloat()
            s.addOnChangeListener { _, _, fromUser -> if (fromUser) persist() }
            sl[k] = s
        }
        for ((k, id) in switchIds) {
            val s = findViewById<MaterialSwitch>(id)
            s.isChecked = sp.getBoolean(k, switchDefs[k] ?: false)
            s.setOnCheckedChangeListener { _, _ -> if (!resetting) persist() }
            sw[k] = s
        }
        for (c in choices) {
            val cur = sp.getInt(c.key, c.def)
            choice[c.key] = cur
            findViewById<MaterialButtonToggleGroup>(c.group).apply {
                check(c.btn[max(0, c.vals.indexOf(cur))])
                addOnButtonCheckedListener { _, id, on ->
                    val i = c.btn.indexOf(id)
                    if (on && i >= 0) {
                        choice[c.key] = c.vals[i]
                        if (!resetting) persist()
                    }
                }
            }
        }
        findViewById<MaterialButtonToggleGroup>(R.id.presets).addOnButtonCheckedListener { _, id, on ->
            val v = presets[id]
            if (on && v != null) {
                presetKeys.forEachIndexed { i, k -> sl[k]?.value = v[i].toFloat() }
                persist()
            }
        }
        findViewById<View>(R.id.btnReset).setOnClickListener { resetAll() }
        findViewById<MaterialButtonToggleGroup>(R.id.tabs).apply {
            addOnButtonCheckedListener { _, id, on -> if (on) showTab(id == R.id.tabPhysics) }
            check(R.id.tabPaint)
        }

        findViewById<Slider>(R.id.brushSize).addOnChangeListener { _, v, _ -> mask.brush = v / 100f }
        findViewById<MaterialButtonToggleGroup>(R.id.tools).apply {
            addOnButtonCheckedListener { _, id, on ->
                if (on) mask.tool = when (id) {
                    R.id.tEraser -> MaskView.Tool.ERASER
                    R.id.tAdd -> MaskView.Tool.WAND_ADD
                    R.id.tSub -> MaskView.Tool.WAND_SUB
                    else -> MaskView.Tool.BRUSH
                }
            }
            check(R.id.tBrush)
        }
        findViewById<View>(R.id.pick).setOnClickListener {
            pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<View>(R.id.apply).setOnClickListener { apply() }
        findViewById<View>(R.id.test).setOnClickListener {
            if (prepare()) startActivity(Intent(this, PreviewActivity::class.java))
        }
        findViewById<View>(R.id.logBtn).setOnClickListener { showLog() }

        Store.load(this)?.let { (bmp, m) -> mask.setImage(bmp, m); Dbg.log("restored saved photo ${bmp.width}x${bmp.height}") }
    }

    override fun onResume() {
        super.onResume()
        status.text = statusText()
        Dbg.log("status: ${status.text}")
    }

    /** Every setting is saved the moment it changes; the wallpaper and the live preview pick it up. */
    private fun persist(refresh: Boolean = true) {
        val e = Store.prefs(this).edit()
        for ((k, s) in sl) e.putInt(k, s.value.toInt())
        for ((k, s) in sw) e.putBoolean(k, s.isChecked)
        for ((k, v) in choice) e.putInt(k, v)
        e.apply()
        if (refresh && live.isShown) live.refresh()
    }

    private fun resetAll() {
        resetting = true
        for ((k, s) in sl) s.value = (sliderDefs[k] ?: 50).toFloat()
        for ((k, s) in sw) s.isChecked = switchDefs[k] ?: false
        for (c in choices) {
            choice[c.key] = c.def
            findViewById<MaterialButtonToggleGroup>(c.group).check(c.btn[max(0, c.vals.indexOf(c.def))])
        }
        resetting = false
        persist()
        Dbg.log("settings reset to defaults")
    }

    private fun showTab(physics: Boolean) {
        panePaint.visibility = if (physics) View.GONE else View.VISIBLE
        panePhysics.visibility = if (physics) View.VISIBLE else View.GONE
        if (physics) {
            mask.visibility = View.INVISIBLE
            live.visibility = View.VISIBLE
            if (!prepare()) { // nothing to preview yet -> go back to painting
                findViewById<MaterialButtonToggleGroup>(R.id.tabs).check(R.id.tabPaint)
            }
        } else {
            live.visibility = View.GONE
            mask.visibility = View.VISIBLE
        }
    }

    /** Is our wallpaper the active one on home / lock screen? */
    private fun statusText(): String = try {
        val wm = WallpaperManager.getInstance(this)
        val name = DropWallpaperService::class.java.name
        val home = wm.getWallpaperInfo(WallpaperManager.FLAG_SYSTEM)?.serviceName == name
        val lock = wm.getWallpaperInfo(WallpaperManager.FLAG_LOCK)?.serviceName == name
        "${Dbg.VERSION} · Home ${if (home) "✓" else "✗"} · Lock ${if (lock) "✓" else "✗"}"
    } catch (e: Exception) {
        Dbg.log("status check failed", e)
        "${Dbg.VERSION} · status unknown"
    }

    private fun load(uri: Uri) {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { d, info, _ ->
                d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val big = max(info.size.width, info.size.height)
                var n = 1
                while (big / n > 2000) n *= 2
                d.setTargetSampleSize(n)
            }
            Dbg.log("picked photo ${bmp.width}x${bmp.height} config=${bmp.config} alpha=${bmp.hasAlpha()}")
            mask.setImage(bmp, null)
        } catch (e: Exception) {
            Dbg.log("photo load failed", e)
            toast(R.string.load_failed)
        }
    }

    /** Pre-flight: photo present, something painted, files saved and read back correctly. */
    private fun prepare(): Boolean {
        val bmp = mask.image ?: return toast(R.string.pick_first)
        val m = mask.maskBytes()
        val painted = m.count { it.toInt() != 0 }
        if (painted == 0) return toast(R.string.paint_first)
        return try {
            persist(false)
            Store.save(this, bmp, m)
            val back = Store.load(this)
            val ok = back != null && back.first.width == bmp.width && back.first.height == bmp.height &&
                back.second.count { it.toInt() != 0 } == painted
            Dbg.log("saved ${bmp.width}x${bmp.height} painted=$painted verified=$ok")
            if (!ok) return toast("Saving failed – tap Log")
            if (live.isShown) live.refresh()
            true
        } catch (e: Exception) {
            Dbg.log("save failed", e)
            toast("Saving failed – tap Log")
        }
    }

    private fun apply() {
        if (!prepare()) return
        val cn = ComponentName(this, DropWallpaperService::class.java)
        try {
            packageManager.getServiceInfo(cn, 0)
        } catch (e: Exception) {
            Dbg.log("wallpaper service not found", e)
            toast("Wallpaper service missing – tap Log")
            return
        }
        val wm = WallpaperManager.getInstance(this)
        Dbg.log("launching preview: supported=${wm.isWallpaperSupported} allowed=${wm.isSetWallpaperAllowed}")
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, cn)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Dbg.log("CHANGE_LIVE_WALLPAPER failed, trying chooser", e)
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Dbg.log("chooser failed", e2)
                toast("Can't open wallpaper picker – tap Log")
            }
        }
    }

    private fun showLog() {
        val tv = TextView(this).apply {
            text = Dbg.read().ifEmpty { "(empty)" }
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(32, 16, 32, 16)
        }
        val sv = ScrollView(this).apply { addView(tv); post { fullScroll(View.FOCUS_DOWN) } }
        MaterialAlertDialogBuilder(this).setTitle("Log").setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("NothingDrop log", Dbg.read()))
                toast("Log copied")
            }
            .setNeutralButton("Clear") { _, _ -> Dbg.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun toast(s: String): Boolean {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        return false
    }

    private fun toast(id: Int): Boolean = toast(getString(id))
}
