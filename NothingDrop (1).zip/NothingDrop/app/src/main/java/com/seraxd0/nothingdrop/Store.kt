package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.util.zip.GZIPInputStream
import java.util.zip.GZIPOutputStream

/** Saves the chosen photo + mask + settings so the wallpaper service can read them. */
object Store {
    @Volatile var error: String? = null
    fun prefs(c: Context) = c.getSharedPreferences("nd", Context.MODE_PRIVATE)
    private fun img(c: Context) = File(c.filesDir, "photo.jpg")
    private fun msk(c: Context) = File(c.filesDir, "mask.gz")

    fun save(c: Context, bmp: Bitmap, mask: ByteArray, strength: Int, elasticity: Int, touch: Boolean) {
        img(c).outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
        DataOutputStream(GZIPOutputStream(msk(c).outputStream())).use {
            it.writeInt(bmp.width); it.writeInt(bmp.height); it.write(mask)
        }
        prefs(c).edit().putInt("strength", strength).putInt("elasticity", elasticity)
            .putBoolean("touch", touch).putLong("rev", System.nanoTime()).apply()
    }

    fun load(c: Context): Pair<Bitmap, ByteArray>? {
        try {
            val bmp = BitmapFactory.decodeFile(img(c).path) ?: run { error = "No saved photo found"; return null }
            DataInputStream(GZIPInputStream(msk(c).inputStream())).use {
                val w = it.readInt(); val h = it.readInt()
                if (w != bmp.width || h != bmp.height) { error = "Mask size mismatch"; return null }
                val m = ByteArray(w * h); it.readFully(m)
                return bmp to m
            }
        } catch (e: Exception) {
            error = e.toString()
            return null
        }
    }
}
