package com.seraxd0.nothingdrop

import android.graphics.Canvas
import android.os.Bundle
import android.view.MotionEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity

/** In-app test of the effect (same renderer as the wallpaper). Tilt, shake or tap. */
class PreviewActivity : AppCompatActivity() {
    private lateinit var r: DropRenderer

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val act = this
        val v = object : View(act) {
            override fun onDraw(c: Canvas) { r.draw(c) }
            override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { r.setSize(w, h) }
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.actionMasked == MotionEvent.ACTION_DOWN) r.poke(e.x, e.y)
                return true
            }
        }
        r = DropRenderer(this) { v.invalidate() }
        setContentView(v)
        Dbg.log("PreviewActivity created")
    }

    override fun onResume() { super.onResume(); r.setVisible(true) }
    override fun onPause() { r.setVisible(false); super.onPause() }
    override fun onDestroy() { r.release(); super.onDestroy() }
}
