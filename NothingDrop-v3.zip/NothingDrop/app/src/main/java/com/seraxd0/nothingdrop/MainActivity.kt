package com.seraxd0.nothingdrop

import android.app.WallpaperManager
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var mask: MaskView
    private lateinit var strength: Slider
    private lateinit var elastic: Slider
    private lateinit var touch: MaterialSwitch
    private lateinit var status: TextView

    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) load(uri)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        mask = findViewById(R.id.mask)
        strength = findViewById(R.id.strength)
        elastic = findViewById(R.id.elastic)
        touch = findViewById(R.id.touch)
        status = findViewById(R.id.status)

        val sp = Store.prefs(this)
        strength.value = sp.getInt("strength", 50).toFloat()
        elastic.value = sp.getInt("elasticity", 60).toFloat()
        touch.isChecked = sp.getBoolean("touch", true)

        findViewById<Slider>(R.id.brushSize).addOnChangeListener { _, v, _ -> mask.brush = v / 100f }
        findViewById<MaterialButtonToggleGroup>(R.id.tools).apply {
            addOnButtonCheckedListener { _, id, on ->
                if (on) mask.tool = when (id) {
                    R.id.tEraser -> MaskView.Tool.ERASER
                    R.id.tAdd -> MaskView.Tool.WAND_ADD
                    R.id.tSub -> MaskView.Tool.WAND_SUB
                    else -> MaskView.Tool.BRUSH
                }
            }
            check(R.id.tBrush)
        }
        findViewById<View>(R.id.pick).setOnClickListener {
            pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<View>(R.id.apply).setOnClickListener { apply() }
        findViewById<View>(R.id.test).setOnClickListener {
            if (prepare()) startActivity(Intent(this, PreviewActivity::class.java))
        }
        findViewById<View>(R.id.logBtn).setOnClickListener { showLog() }

        Store.load(this)?.let { (bmp, m) -> mask.setImage(bmp, m); Dbg.log("restored saved photo ${bmp.width}x${bmp.height}") }
    }

    override fun onResume() {
        super.onResume()
        status.text = statusText()
        Dbg.log("status: ${status.text}")
    }

    /** Is our wallpaper the active one on home / lock screen? */
    private fun statusText(): String = try {
        val wm = WallpaperManager.getInstance(this)
        val name = DropWallpaperService::class.java.name
        val home = wm.getWallpaperInfo(WallpaperManager.FLAG_SYSTEM)?.serviceName == name
        val lock = wm.getWallpaperInfo(WallpaperManager.FLAG_LOCK)?.serviceName == name
        "${Dbg.VERSION} · Home ${if (home) "✓" else "✗"} · Lock ${if (lock) "✓" else "✗"}"
    } catch (e: Exception) {
        Dbg.log("status check failed", e)
        "${Dbg.VERSION} · status unknown"
    }

    private fun load(uri: Uri) {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { d, info, _ ->
                d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val big = max(info.size.width, info.size.height)
                var n = 1
                while (big / n > 2000) n *= 2
                d.setTargetSampleSize(n)
            }
            Dbg.log("picked photo ${bmp.width}x${bmp.height} config=${bmp.config} alpha=${bmp.hasAlpha()}")
            mask.setImage(bmp, null)
        } catch (e: Exception) {
            Dbg.log("photo load failed", e)
            toast(R.string.load_failed)
        }
    }

    /** Pre-flight: photo present, something painted, files saved and read back correctly. */
    private fun prepare(): Boolean {
        val bmp = mask.image ?: return toast(R.string.pick_first)
        val m = mask.maskBytes()
        val painted = m.count { it.toInt() != 0 }
        if (painted == 0) return toast(R.string.paint_first)
        return try {
            Store.save(this, bmp, m, strength.value.toInt(), elastic.value.toInt(), touch.isChecked)
            val back = Store.load(this)
            val ok = back != null && back.first.width == bmp.width && back.first.height == bmp.height &&
                back.second.count { it.toInt() != 0 } == painted
            Dbg.log("saved ${bmp.width}x${bmp.height} painted=$painted verified=$ok")
            if (!ok) toast("Saving failed – tap Log") else true
        } catch (e: Exception) {
            Dbg.log("save failed", e)
            toast("Saving failed – tap Log")
        }
    }

    private fun apply() {
        if (!prepare()) return
        val cn = ComponentName(this, DropWallpaperService::class.java)
        try {
            packageManager.getServiceInfo(cn, 0)
        } catch (e: Exception) {
            Dbg.log("wallpaper service not found", e)
            toast("Wallpaper service missing – tap Log")
            return
        }
        val wm = WallpaperManager.getInstance(this)
        Dbg.log("launching preview: supported=${wm.isWallpaperSupported} allowed=${wm.isSetWallpaperAllowed}")
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER)
            .putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT, cn)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Dbg.log("CHANGE_LIVE_WALLPAPER failed, trying chooser", e)
            try {
                startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
            } catch (e2: Exception) {
                Dbg.log("chooser failed", e2)
                toast("Can't open wallpaper picker – tap Log")
            }
        }
    }

    private fun showLog() {
        val tv = TextView(this).apply {
            text = Dbg.read().ifEmpty { "(empty)" }
            textSize = 10f
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
            setPadding(32, 16, 32, 16)
        }
        val sv = ScrollView(this).apply { addView(tv); post { fullScroll(View.FOCUS_DOWN) } }
        MaterialAlertDialogBuilder(this).setTitle("Log").setView(sv)
            .setPositiveButton("Copy") { _, _ ->
                val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("NothingDrop log", Dbg.read()))
                toast("Log copied")
            }
            .setNeutralButton("Clear") { _, _ -> Dbg.clear() }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun toast(s: String): Boolean {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
        return false
    }

    private fun toast(id: Int): Boolean = toast(getString(id))
}
