package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Shared by the live wallpaper and the in-app Test screen.
 * - The photo/mesh is built on a background thread (never blocks the UI / system).
 * - draw() never throws; problems are logged and shown as text on screen.
 * - Frames are only produced while something is moving.
 * Call everything from the main thread.
 */
class DropRenderer(ctx: Context, private val redraw: () -> Unit) : SensorEventListener {
    private class Scene(
        val bmp: Bitmap, val cols: Int, val rows: Int, val base: FloatArray,
        val verts: FloatArray, val wt: FloatArray, val act: IntArray, val cx: Float, val cy: Float
    )

    private val app = ctx.applicationContext
    private val sm = app.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    private val main = Handler(Looper.getMainLooper())
    private var W = 0
    private var H = 0
    private var visible = false
    private var running = false
    private var dead = false
    private var loading = false
    private var gen = 0
    private var rev = -1L
    private var scene: Scene? = null
    private var err: String? = null
    private var maxPx = 0f
    private var damp = 0.3f
    private var touchOn = true
    private var x = 0f
    private var y = 0f
    private var vx = 0f
    private var vy = 0f
    private var tx = 0f
    private var ty = 0f
    private val g = FloatArray(3)
    private val gs = FloatArray(3)
    private var haveG = false
    private var lastNs = 0L
    private var lastSensor = 0L
    private var lastPoke = 0L
    private var firstFrame = true

    private val frame = Choreographer.FrameCallback { t ->
        running = false
        if (visible && !dead) {
            try {
                val dt = if (lastNs == 0L) 0.016f else ((t - lastNs) / 1e9f).coerceIn(0.001f, 0.032f)
                lastNs = t
                step(dt)
                redraw()
                if (settled()) lastNs = 0 else go()
            } catch (e: Throwable) {
                Dbg.log("frame failed", e)
            }
        }
    }

    private fun go() {
        if (!running && visible && !dead) {
            running = true
            Choreographer.getInstance().postFrameCallback(frame)
        }
    }

    private fun settled() = abs(tx - x) < 0.25f && abs(ty - y) < 0.25f && abs(vx) < 1f && abs(vy) < 1f

    // ---------------------------------------------------------------- lifecycle

    fun setSize(w: Int, h: Int) {
        if (dead || w <= 0 || h <= 0 || (w == W && h == H)) return
        W = w; H = h
        Dbg.log("surface size ${w}x$h")
        reload(true)
    }

    fun setVisible(v: Boolean) {
        if (dead || v == visible) return
        visible = v
        Dbg.log("visible=$v")
        if (v) {
            reload(false)
            haveG = false; lastNs = 0; lastSensor = 0
            try {
                if (acc != null) sm.registerListener(this, acc, SensorManager.SENSOR_DELAY_GAME)
                else Dbg.log("no accelerometer: tilt/shake disabled")
            } catch (e: Throwable) {
                Dbg.log("sensor register failed", e)
            }
            redraw()
        } else {
            try { sm.unregisterListener(this) } catch (e: Throwable) { }
            Choreographer.getInstance().removeFrameCallback(frame)
            running = false
        }
    }

    fun release() {
        dead = true
        try { sm.unregisterListener(this) } catch (e: Throwable) { }
        Choreographer.getInstance().removeFrameCallback(frame)
        scene = null
        Dbg.log("renderer released")
    }

    private fun readPrefs(): Long {
        val sp = Store.prefs(app)
        maxPx = (0.01f + 0.05f * (sp.getInt("strength", 50) / 100f)) * W
        damp = 0.85f - 0.75f * (sp.getInt("elasticity", 60) / 100f)
        touchOn = sp.getBoolean("touch", true)
        return sp.getLong("rev", 0)
    }

    /** (Re)build the scene in the background if the app saved something new. */
    private fun reload(force: Boolean) {
        if (dead || W == 0 || H == 0) return
        val r = readPrefs()
        if (!force && r == rev && (scene != null || loading)) return
        rev = r
        val id = ++gen
        val w = W
        val h = H
        loading = true
        Dbg.log("reload start ${w}x$h rev=$r")
        Thread({
            try {
                val s = build(w, h)
                main.post {
                    if (!dead && id == gen) {
                        scene = s; err = null; loading = false
                        x = 0f; y = 0f; vx = 0f; vy = 0f
                        redraw()
                    }
                }
            } catch (t: Throwable) {
                Dbg.log("scene build failed", t)
                main.post {
                    if (!dead && id == gen) {
                        scene = null; loading = false
                        err = "${t.javaClass.simpleName}: ${t.message}"
                        redraw()
                    }
                }
            }
        }, "nd-build").start()
    }

    // ---------------------------------------------------------------- scene

    private fun build(sw: Int, sh: Int): Scene {
        val t0 = System.nanoTime()
        val (photo, m) = Store.load(app) ?: throw IllegalStateException(Store.error ?: "No saved photo")
        val pw = photo.width
        val ph = photo.height
        if (m.none { it.toInt() != 0 }) throw IllegalStateException("Saved mask is empty")
        val s = max(sw.toFloat() / pw, sh.toFloat() / ph)
        val dw = pw * s
        val dh = ph * s
        val out = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
        Canvas(out).apply {
            drawColor(Color.BLACK)
            drawBitmap(photo, null, RectF((sw - dw) / 2, (sh - dh) / 2, (sw + dw) / 2, (sh + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
        }
        photo.recycle()

        val cell = max(16f, sw / 45f)
        val cols = ceil(sw / cell).toInt()
        val rows = ceil(sh / cell).toInt()
        val nc = cols + 1
        val n = nc * (rows + 1)
        val base = FloatArray(n * 2)
        val wt = FloatArray(n)
        val ox = (pw * s - sw) / 2
        val oy = (ph * s - sh) / 2
        fun at(px: Float, py: Float): Float {
            val i = ((px + ox) / s).toInt().coerceIn(0, pw - 1)
            val j = ((py + oy) / s).toInt().coerceIn(0, ph - 1)
            return (m[j * pw + i].toInt() and 255) / 255f
        }
        val hf = cell / 2
        for (j in 0..rows) for (i in 0..cols) {
            val px = i * sw.toFloat() / cols
            val py = j * sh.toFloat() / rows
            val k = j * nc + i
            base[2 * k] = px; base[2 * k + 1] = py
            wt[k] = (2 * at(px, py) + at(px - hf, py - hf) + at(px + hf, py - hf) +
                at(px - hf, py + hf) + at(px + hf, py + hf)) / 6
        }
        repeat(3) { blur(wt, nc, rows + 1) }
        var aw = 0f
        var ax = 0f
        var ay = 0f
        val list = ArrayList<Int>()
        for (j in 0..rows) for (i in 0..cols) {
            val k = j * nc + i
            // fade to 0 near the screen border so the picture never tears away from the edge
            wt[k] *= min(1f, min(min(i, cols - i), min(j, rows - j)) / 3f)
            if (wt[k] > 0.003f) {
                list.add(k); aw += wt[k]; ax += wt[k] * base[2 * k]; ay += wt[k] * base[2 * k + 1]
            }
        }
        val cx = if (aw > 0) ax / aw else sw / 2f
        val cy = if (aw > 0) ay / aw else sh / 2f
        Dbg.log("scene built ${sw}x$sh photo=${pw}x$ph mesh=${cols}x$rows active=${list.size} in ${(System.nanoTime() - t0) / 1_000_000}ms")
        return Scene(out, cols, rows, base, base.copyOf(), wt, list.toIntArray(), cx, cy)
    }

    private fun blur(a: FloatArray, w: Int, h: Int) {
        val o = FloatArray(a.size)
        for (j in 0 until h) for (i in 0 until w) {
            var s = 0f
            for (dj in -1..1) for (di in -1..1)
                s += a[(j + dj).coerceIn(0, h - 1) * w + (i + di).coerceIn(0, w - 1)]
            o[j * w + i] = s / 9
        }
        o.copyInto(a)
    }

    // ---------------------------------------------------------------- drawing

    fun draw(c: Canvas) {
        try {
            val s = scene
            if (s == null) {
                c.drawColor(0xFF111318.toInt())
                note(c, err ?: if (loading) "Loading…" else "Nothing saved yet. Open NothingDrop, paint an area and tap Set wallpaper.")
                return
            }
            if (abs(x) < 0.01f && abs(y) < 0.01f) {
                c.drawBitmap(s.bmp, 0f, 0f, null)
            } else {
                for (k in s.act) {
                    s.verts[2 * k] = s.base[2 * k] + s.wt[k] * x
                    s.verts[2 * k + 1] = s.base[2 * k + 1] + s.wt[k] * y
                }
                c.drawBitmapMesh(s.bmp, s.cols, s.rows, s.verts, 0, null, 0, null)
            }
            if (firstFrame) { firstFrame = false; Dbg.log("first frame drawn ${c.width}x${c.height}") }
        } catch (t: Throwable) {
            Dbg.log("draw failed", t)
            try { c.drawColor(0xFF111318.toInt()); note(c, "draw: $t") } catch (e: Throwable) { }
        }
    }

    private fun note(c: Canvas, msg: String) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = c.width / 26f }
        var yy = c.height / 2f
        for (line in msg.chunked(30)) {
            c.drawText(line, 40f, yy, p)
            yy += p.textSize * 1.3f
        }
    }

    // ---------------------------------------------------------------- motion

    /** Damped spring pulling the offset toward the tilt target. */
    private fun step(dt: Float) {
        val w0 = 9.4f
        val k = w0 * w0
        val c = 2 * damp * w0
        vx += (k * (tx - x) - c * vx) * dt
        vy += (k * (ty - y) - c * vy) * dt
        x += vx * dt; y += vy * dt
        val lim = maxPx * 2
        x = x.coerceIn(-lim, lim); y = y.coerceIn(-lim, lim)
    }

    override fun onSensorChanged(e: SensorEvent) {
        try {
            val a = e.values
            if (!haveG) { for (i in 0..2) { g[i] = a[i]; gs[i] = a[i] }; haveG = true }
            for (i in 0..2) { g[i] += 0.12f * (a[i] - g[i]); gs[i] += 0.01f * (a[i] - gs[i]) }
            // tilt: object slides "downhill" relative to how the phone was being held
            val kt = maxPx / 4.9f
            val lim = maxPx * 1.3f
            tx = (-(g[0] - gs[0]) * kt).coerceIn(-lim, lim)
            ty = ((g[1] - gs[1]) * kt).coerceIn(-lim, lim)
            // shake: inertia kick opposite to the phone's own acceleration
            val dt = if (lastSensor == 0L) 0.02f else ((e.timestamp - lastSensor) / 1e9f).coerceIn(0.005f, 0.05f)
            lastSensor = e.timestamp
            val lx = a[0] - g[0]
            val ly = a[1] - g[1]
            val kick = abs(lx) + abs(ly) > 1.5f
            if (kick) {
                val gain = maxPx * 6 * dt
                val vm = maxPx * 20
                vx = (vx - lx * gain).coerceIn(-vm, vm)
                vy = (vy + ly * gain).coerceIn(-vm, vm)
            }
            if (scene != null && (kick || abs(tx - x) > 0.5f || abs(ty - y) > 0.5f)) go()
        } catch (t: Throwable) {
            Dbg.log("sensor failed", t)
        }
    }

    override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

    /** Tap: push the object away from the finger. */
    fun poke(px: Float, py: Float) {
        val s = scene ?: return
        val now = System.nanoTime()
        if (!touchOn || !visible || now - lastPoke < 150_000_000L) return
        lastPoke = now
        val dx = s.cx - px
        val dy = s.cy - py
        val d = hypot(dx, dy).coerceAtLeast(1f)
        val v = maxPx * 11f * (1.2f - 0.6f * min(1f, d / max(H, 1)))
        vx += dx / d * v; vy += dy / d * v
        go()
    }
}
