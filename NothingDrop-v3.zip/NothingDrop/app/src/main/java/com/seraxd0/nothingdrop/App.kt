package com.seraxd0.nothingdrop

import android.app.ActivityManager
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Dbg.init(this)
        val old = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            Dbg.log("CRASH in thread ${t.name}", e)
            old?.uncaughtException(t, e)
        }
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        Dbg.log(
            "App ${Dbg.VERSION} | ${Build.MANUFACTURER} ${Build.MODEL} | Android ${Build.VERSION.RELEASE} " +
                "(API ${Build.VERSION.SDK_INT}) | ${Build.DISPLAY} | heap ${am.memoryClass}MB | " +
                "liveWallpaperFeature=${packageManager.hasSystemFeature(PackageManager.FEATURE_LIVE_WALLPAPER)} | " +
                "process=${Application.getProcessName()}"
        )
    }
}
