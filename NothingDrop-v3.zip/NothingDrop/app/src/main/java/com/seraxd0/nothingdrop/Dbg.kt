package com.seraxd0.nothingdrop

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Tiny file logger so problems can be read inside the app (Log button). */
object Dbg {
    const val VERSION = "v3"
    private var file: File? = null
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun init(c: Context) {
        val f = File(c.filesDir, "log.txt")
        if (f.length() > 200_000) f.delete()
        file = f
    }

    @Synchronized
    fun log(msg: String, t: Throwable? = null) {
        val text = if (t == null) msg else msg + "\n" + android.util.Log.getStackTraceString(t)
        android.util.Log.d("NothingDrop", text)
        try {
            file?.appendText("${fmt.format(Date())} ${Thread.currentThread().name}: $text\n")
        } catch (e: Exception) {
        }
    }

    fun read(): String = try {
        file?.readText()?.takeLast(15000) ?: ""
    } catch (e: Exception) {
        "cannot read log: $e"
    }

    fun clear() {
        try { file?.writeText("") } catch (e: Exception) { }
    }
}
