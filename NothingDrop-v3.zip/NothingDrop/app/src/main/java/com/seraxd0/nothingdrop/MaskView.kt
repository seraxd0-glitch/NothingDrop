package com.seraxd0.nothingdrop

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.min

/** Shows the photo and lets the user paint the "jiggle" mask (brush / eraser / magic wand). */
class MaskView @JvmOverloads constructor(c: Context, a: AttributeSet? = null) : View(c, a) {
    enum class Tool { BRUSH, ERASER, WAND_ADD, WAND_SUB }

    var tool = Tool.BRUSH
    var brush = 0.5f
    var image: Bitmap? = null
        private set
    private var mask: Bitmap? = null
    private var mc: Canvas? = null
    private var src: IntArray? = null
    private val dst = RectF()
    private var sc = 1f
    private var lx = 0f
    private var ly = 0f
    private val ink = 0xFF22D3EE.toInt()
    private val pen = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = ink; strokeCap = Paint.Cap.ROUND }
    private val rub = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR); strokeCap = Paint.Cap.ROUND
    }
    private val show = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 150 }
    private val plain = Paint(Paint.FILTER_BITMAP_FLAG)

    fun setImage(bmp: Bitmap, m: ByteArray?) {
        image = bmp; src = null
        val w = bmp.width; val h = bmp.height
        val mb = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        mask = mb; mc = Canvas(mb)
        if (m != null && m.size == w * h) {
            val px = IntArray(w * h) { ((m[it].toInt() and 255) shl 24) or (ink and 0xFFFFFF) }
            mb.setPixels(px, 0, w, 0, 0, w, h)
        }
        invalidate()
    }

    fun maskBytes(): ByteArray {
        val b = mask ?: return ByteArray(0)
        val w = b.width; val h = b.height
        val p = IntArray(w * h); b.getPixels(p, 0, w, 0, 0, w, h)
        return ByteArray(p.size) { (p[it] ushr 24).toByte() }
    }

    override fun onDraw(c: Canvas) {
        val i = image ?: return
        sc = min(width / i.width.toFloat(), height / i.height.toFloat())
        val dw = i.width * sc; val dh = i.height * sc
        dst.set((width - dw) / 2, (height - dh) / 2, (width + dw) / 2, (height + dh) / 2)
        c.drawBitmap(i, null, dst, plain)
        c.drawBitmap(mask!!, null, dst, show)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val i = image ?: return false
        val x = (e.x - dst.left) / sc
        val y = (e.y - dst.top) / sc
        val d = (0.02f + 0.2f * brush) * min(i.width, i.height)
        val p = if (tool == Tool.ERASER) rub else pen
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent.requestDisallowInterceptTouchEvent(true)
                when (tool) {
                    Tool.WAND_ADD -> wand(x.toInt(), y.toInt(), true)
                    Tool.WAND_SUB -> wand(x.toInt(), y.toInt(), false)
                    else -> { p.style = Paint.Style.FILL; mc!!.drawCircle(x, y, d / 2, p) }
                }
            }
            MotionEvent.ACTION_MOVE -> if (tool == Tool.BRUSH || tool == Tool.ERASER) {
                p.style = Paint.Style.STROKE; p.strokeWidth = d
                mc!!.drawLine(lx, ly, x, y, p)
            }
            else -> return true
        }
        lx = x; ly = y
        invalidate()
        return true
    }

    private fun close(a: Int, b: Int): Boolean {
        val r = (a shr 16 and 255) - (b shr 16 and 255)
        val g = (a shr 8 and 255) - (b shr 8 and 255)
        val bl = (a and 255) - (b and 255)
        return r * r + g * g + bl * bl < 2304 // colour distance < 48
    }

    /** Flood-fill the region of similar colour under the tap. */
    private fun wand(sx: Int, sy: Int, add: Boolean) {
        val i = image ?: return
        val m = mask ?: return
        val w = i.width; val h = i.height
        if (sx !in 0 until w || sy !in 0 until h) return
        val px = src ?: IntArray(w * h).also { i.getPixels(it, 0, w, 0, 0, w, h); src = it }
        val mp = IntArray(w * h); m.getPixels(mp, 0, w, 0, 0, w, h)
        val seed = px[sy * w + sx]
        val seen = BooleanArray(w * h)
        val q = IntArray(w * h)
        var head = 0; var tail = 0
        q[tail++] = sy * w + sx; seen[q[0]] = true
        fun push(n: Int) { if (!seen[n] && close(px[n], seed)) { seen[n] = true; q[tail++] = n } }
        val fill = if (add) ink else 0
        while (head < tail) {
            val k = q[head++]
            mp[k] = fill
            val cx = k % w
            if (cx > 0) push(k - 1)
            if (cx < w - 1) push(k + 1)
            if (k >= w) push(k - w)
            if (k < w * h - w) push(k + w)
        }
        m.setPixels(mp, 0, w, 0, 0, w, h)
    }
}
