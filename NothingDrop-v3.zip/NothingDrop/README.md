# NothingDrop

Depth / jiggle live wallpaper for Nothing phones (Origin OS 7 style). Paint the part of a photo
that should move, then set it as your home and/or lock screen wallpaper.

- Tools: brush, eraser, magic wand + / − (selects by colour)
- Settings: strength, elasticity, jiggle on touch
- Reacts to tilt, shake and taps; only draws frames while it is moving (battery friendly)
- No special permissions needed (the system wallpaper preview asks Home / Lock / Both)
- **Log** button in the app shows diagnostics; **Test** previews the effect inside the app

## Build

No Android Studio needed: push to `main` and GitHub Actions builds the APK
(**Actions → Build APK → NothingDrop-debug artifact**). Install `app-debug.apk` on your phone.

Locally: `gradle assembleDebug` (Gradle 8.9, JDK 17, Android SDK 34).

## Use

1. Open the app, tap **Photo**, pick an image.
2. Paint the object (or tap it with the wand), tune the sliders.
3. **Set wallpaper** → in the preview choose Home screen / Lock screen / Both.
Re-open the app any time to edit the saved photo and apply again.
