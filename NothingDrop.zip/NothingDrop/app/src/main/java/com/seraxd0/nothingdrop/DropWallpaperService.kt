package com.seraxd0.nothingdrop

import android.app.WallpaperManager
import android.graphics.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.service.wallpaper.WallpaperService
import android.view.Choreographer
import android.view.MotionEvent
import android.view.SurfaceHolder
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/**
 * Live wallpaper: the painted area is a soft-edged mesh region that springs around
 * when the phone is tilted / shaken / tapped. Frames are only drawn while it moves.
 */
class DropWallpaperService : WallpaperService() {
    override fun onCreateEngine(): Engine = DropEngine()

    private inner class DropEngine : Engine(), SensorEventListener {
        private val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        private val acc: Sensor? = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        private var visible = false
        private var running = false
        private var W = 0
        private var H = 0
        private var rev = -1L
        private var bmp: Bitmap? = null
        private var cols = 0
        private var rows = 0
        private var base = FloatArray(0)
        private var verts = FloatArray(0)
        private var wt = FloatArray(0)
        private var act = IntArray(0)
        private var cx = 0f
        private var cy = 0f
        private var maxPx = 0f
        private var damp = 0.3f
        private var touchOn = true
        private var x = 0f
        private var y = 0f
        private var vx = 0f
        private var vy = 0f
        private var tx = 0f
        private var ty = 0f
        private val g = FloatArray(3)
        private val gs = FloatArray(3)
        private var haveG = false
        private var lastNs = 0L
        private var lastSensor = 0L
        private var lastPoke = 0L

        private val frame = Choreographer.FrameCallback { t ->
            running = false
            if (visible) {
                val dt = if (lastNs == 0L) 0.016f else ((t - lastNs) / 1e9f).coerceIn(0.001f, 0.032f)
                lastNs = t
                step(dt)
                draw()
                if (settled()) lastNs = 0 else go()
            }
        }

        private fun go() {
            if (!running && visible) { running = true; Choreographer.getInstance().postFrameCallback(frame) }
        }

        private fun settled() = abs(tx - x) < 0.25f && abs(ty - y) < 0.25f && abs(vx) < 1f && abs(vy) < 1f

        override fun onSurfaceChanged(h: SurfaceHolder, format: Int, w: Int, hh: Int) {
            W = w; H = hh; rev = -1
            reload(); draw()
        }

        override fun onVisibilityChanged(v: Boolean) {
            visible = v
            if (v) {
                reload()
                haveG = false; lastNs = 0; lastSensor = 0
                acc?.let { sm.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
                draw()
            } else {
                sm.unregisterListener(this)
                Choreographer.getInstance().removeFrameCallback(frame)
                running = false
            }
        }

        override fun onDestroy() {
            visible = false
            sm.unregisterListener(this)
            Choreographer.getInstance().removeFrameCallback(frame)
            bmp = null
        }

        /** (Re)load settings; rebuild image + mesh only if the app saved something new. */
        private fun reload() {
            if (W == 0) return
            val sp = Store.prefs(applicationContext)
            val s = sp.getInt("strength", 50) / 100f
            maxPx = (0.01f + 0.05f * s) * W
            damp = 0.85f - 0.75f * (sp.getInt("elasticity", 60) / 100f)
            touchOn = sp.getBoolean("touch", true)
            setTouchEventsEnabled(touchOn)
            val r = sp.getLong("rev", 0)
            if (r == rev && bmp != null) return
            rev = r
            val (photo, m) = Store.load(applicationContext) ?: run { bmp = null; return }
            val pw = photo.width; val ph = photo.height
            val sc = max(W.toFloat() / pw, H.toFloat() / ph)
            val dw = pw * sc; val dh = ph * sc
            val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
            Canvas(out).drawBitmap(
                photo, null, RectF((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2),
                Paint(Paint.FILTER_BITMAP_FLAG)
            )
            photo.recycle()
            bmp = out
            buildMesh(pw, ph, m, sc)
            x = 0f; y = 0f; vx = 0f; vy = 0f
        }

        /** Per-vertex weight = blurred mask; weight 1 moves fully, 0 stays pinned. */
        private fun buildMesh(mw: Int, mh: Int, m: ByteArray, s: Float) {
            val cell = max(16f, W / 45f)
            cols = ceil(W / cell).toInt(); rows = ceil(H / cell).toInt()
            val nc = cols + 1
            val n = nc * (rows + 1)
            base = FloatArray(n * 2); wt = FloatArray(n)
            val ox = (mw * s - W) / 2; val oy = (mh * s - H) / 2
            fun at(px: Float, py: Float): Float {
                val i = ((px + ox) / s).toInt().coerceIn(0, mw - 1)
                val j = ((py + oy) / s).toInt().coerceIn(0, mh - 1)
                return (m[j * mw + i].toInt() and 255) / 255f
            }
            val hf = cell / 2
            for (j in 0..rows) for (i in 0..cols) {
                val px = i * W.toFloat() / cols; val py = j * H.toFloat() / rows
                val k = j * nc + i
                base[2 * k] = px; base[2 * k + 1] = py
                wt[k] = (2 * at(px, py) + at(px - hf, py - hf) + at(px + hf, py - hf) +
                        at(px - hf, py + hf) + at(px + hf, py + hf)) / 6
            }
            repeat(3) { blur(nc, rows + 1) }
            var aw = 0f; var ax = 0f; var ay = 0f
            val list = ArrayList<Int>()
            for (j in 0..rows) for (i in 0..cols) {
                val k = j * nc + i
                // fade to 0 near the screen border so the picture never tears away from the edge
                wt[k] *= min(1f, min(min(i, cols - i), min(j, rows - j)) / 3f)
                if (wt[k] > 0.003f) {
                    list.add(k); aw += wt[k]; ax += wt[k] * base[2 * k]; ay += wt[k] * base[2 * k + 1]
                }
            }
            act = list.toIntArray()
            cx = if (aw > 0) ax / aw else W / 2f
            cy = if (aw > 0) ay / aw else H / 2f
            verts = base.copyOf()
        }

        private fun blur(w: Int, h: Int) {
            val o = FloatArray(wt.size)
            for (j in 0 until h) for (i in 0 until w) {
                var s = 0f
                for (dj in -1..1) for (di in -1..1)
                    s += wt[(j + dj).coerceIn(0, h - 1) * w + (i + di).coerceIn(0, w - 1)]
                o[j * w + i] = s / 9
            }
            o.copyInto(wt)
        }

        /** Damped spring pulling the offset toward the tilt target. */
        private fun step(dt: Float) {
            val w0 = 9.4f
            val k = w0 * w0
            val c = 2 * damp * w0
            vx += (k * (tx - x) - c * vx) * dt
            vy += (k * (ty - y) - c * vy) * dt
            x += vx * dt; y += vy * dt
            val lim = maxPx * 2
            x = x.coerceIn(-lim, lim); y = y.coerceIn(-lim, lim)
        }

        private fun draw() {
            val b = bmp
            val c = (try { surfaceHolder.lockHardwareCanvas() } catch (e: Exception) { null }) ?: return
            try {
                if (b == null) {
                    c.drawColor(0xFF111318.toInt())
                } else {
                    for (k in act) {
                        verts[2 * k] = base[2 * k] + wt[k] * x
                        verts[2 * k + 1] = base[2 * k + 1] + wt[k] * y
                    }
                    c.drawBitmapMesh(b, cols, rows, verts, 0, null, 0, null)
                }
            } finally {
                surfaceHolder.unlockCanvasAndPost(c)
            }
        }

        override fun onSensorChanged(e: SensorEvent) {
            val a = e.values
            if (!haveG) { for (i in 0..2) { g[i] = a[i]; gs[i] = a[i] }; haveG = true }
            for (i in 0..2) { g[i] += 0.12f * (a[i] - g[i]); gs[i] += 0.01f * (a[i] - gs[i]) }
            // tilt: object slides "downhill" relative to how the phone was being held
            val kt = maxPx / 4.9f
            val lim = maxPx * 1.3f
            tx = (-(g[0] - gs[0]) * kt).coerceIn(-lim, lim)
            ty = ((g[1] - gs[1]) * kt).coerceIn(-lim, lim)
            // shake: inertia kick opposite to the phone's own acceleration
            val dt = if (lastSensor == 0L) 0.02f else ((e.timestamp - lastSensor) / 1e9f).coerceIn(0.005f, 0.05f)
            lastSensor = e.timestamp
            val lx = a[0] - g[0]; val ly = a[1] - g[1]
            val kick = abs(lx) + abs(ly) > 1.5f
            if (kick) {
                val gain = maxPx * 6 * dt
                val vm = maxPx * 20
                vx = (vx - lx * gain).coerceIn(-vm, vm)
                vy = (vy + ly * gain).coerceIn(-vm, vm)
            }
            if (kick || abs(tx - x) > 0.5f || abs(ty - y) > 0.5f) go()
        }

        override fun onAccuracyChanged(s: Sensor?, accuracy: Int) {}

        /** Tap: push the object away from the finger. */
        private fun poke(px: Float, py: Float) {
            val now = System.nanoTime()
            if (!touchOn || !visible || now - lastPoke < 150_000_000L) return
            lastPoke = now
            val dx = cx - px; val dy = cy - py
            val d = hypot(dx, dy).coerceAtLeast(1f)
            val v = maxPx * 11f * (1.2f - 0.6f * min(1f, d / H))
            vx += dx / d * v; vy += dy / d * v
            go()
        }

        override fun onTouchEvent(ev: MotionEvent) {
            if (ev.actionMasked == MotionEvent.ACTION_DOWN) poke(ev.x, ev.y)
        }

        // launchers forward home-screen taps as commands instead of touch events
        override fun onCommand(action: String?, px: Int, py: Int, z: Int, extras: Bundle?, resultRequested: Boolean): Bundle? {
            if (action == WallpaperManager.COMMAND_TAP) poke(px.toFloat(), py.toFloat())
            return null
        }
    }
}
