package com.seraxd0.nothingdrop

import android.app.WallpaperManager
import android.content.ActivityNotFoundException
import android.content.ComponentName
import android.content.Intent
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.button.MaterialButtonToggleGroup
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider
import kotlin.math.max

class MainActivity : AppCompatActivity() {
    private lateinit var mask: MaskView
    private lateinit var strength: Slider
    private lateinit var elastic: Slider
    private lateinit var touch: MaterialSwitch

    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) load(uri)
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setContentView(R.layout.activity_main)
        mask = findViewById(R.id.mask)
        strength = findViewById(R.id.strength)
        elastic = findViewById(R.id.elastic)
        touch = findViewById(R.id.touch)

        val sp = Store.prefs(this)
        strength.value = sp.getInt("strength", 50).toFloat()
        elastic.value = sp.getInt("elasticity", 60).toFloat()
        touch.isChecked = sp.getBoolean("touch", true)

        findViewById<Slider>(R.id.brushSize).addOnChangeListener { _, v, _ -> mask.brush = v / 100f }
        findViewById<MaterialButtonToggleGroup>(R.id.tools).apply {
            addOnButtonCheckedListener { _, id, on ->
                if (on) mask.tool = when (id) {
                    R.id.tEraser -> MaskView.Tool.ERASER
                    R.id.tAdd -> MaskView.Tool.WAND_ADD
                    R.id.tSub -> MaskView.Tool.WAND_SUB
                    else -> MaskView.Tool.BRUSH
                }
            }
            check(R.id.tBrush)
        }
        findViewById<View>(R.id.pick).setOnClickListener {
            pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
        findViewById<View>(R.id.apply).setOnClickListener { apply() }

        Store.load(this)?.let { (bmp, m) -> mask.setImage(bmp, m) }
    }

    private fun load(uri: Uri) {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { d, info, _ ->
                d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val big = max(info.size.width, info.size.height)
                var n = 1
                while (big / n > 2000) n *= 2
                d.setTargetSampleSize(n)
            }
            mask.setImage(bmp, null)
        } catch (e: Exception) {
            Toast.makeText(this, R.string.load_failed, Toast.LENGTH_SHORT).show()
        }
    }

    private fun apply() {
        val bmp = mask.image
        if (bmp == null) { Toast.makeText(this, R.string.pick_first, Toast.LENGTH_SHORT).show(); return }
        val m = mask.maskBytes()
        if (m.none { it.toInt() != 0 }) { Toast.makeText(this, R.string.paint_first, Toast.LENGTH_SHORT).show(); return }
        Store.save(this, bmp, m, strength.value.toInt(), elastic.value.toInt(), touch.isChecked)
        // System preview lets you choose Home screen / Lock screen / Both.
        val i = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).putExtra(
            WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
            ComponentName(this, DropWallpaperService::class.java)
        )
        try { startActivity(i) } catch (e: ActivityNotFoundException) {
            startActivity(Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER))
        }
    }
}
